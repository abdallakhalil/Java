package Tut04;

public class GameOfLife {

    /* Methode um ein Array auszugeben. Wie im Rest des Programms werden die äußeren Zeilen und Spalten nicht
     * ausgegeben. Die Codes \ u... sind Unicode Zeichen.*/
    public static void printField (int[][] n){
        for (int i = 1; i < n.length -1; i++){
            System.out.print("");
            for (int j = 1; j < n.length -1; j++){
                if (n[i][j] == 1){
                    System.out.print("\u2689");
                }
                else System.out.print("\u2810");
                if (j != n.length - 1) {
                    System.out.print(" ");
                }
            }
            System.out.println("");
        }
    }

    /* Diese Methode implementiert die Regeln des Game of Life. Sie erhält zwei Arrays als Parameter: Das, welches
    die Anzahl der Nachbarn speichert, und das mit der dazugehörigen aktuellen Generation. */
    public static int[][] nextGen (int[][] neighborCount, int[][] gen) {
        /* Die Werte in neighborCount werden nach den Regeln des Game of Life wieder zu Nullen und Einsen umgewandelt
        für die else Anweisung wird Array gen benötigt, da hier die Fälle abgedeckt werden, in denen eine Stelle 2 oder
        3 Nachbarn hat, die Stelle also ihren Zustand beibehält. Nur mit Verweis auf die jeweilige Stelle in gen
        kann nachvollzogen werden ob es sich um eine 1 oder 0 handelt. */

        for (int i = 1; i < gen.length - 1; i++) {
            for (int j = 1; j < gen.length - 1; j++) {
                if (neighborCount[i][j] < 2 || neighborCount[i][j] > 3) {
                    neighborCount[i][j] = 0;
                } else if (neighborCount[i][j] == 3) {
                    neighborCount[i][j] = 1;
                } else neighborCount[i][j] = gen[i][j];
            }
        }
        return neighborCount;
    }

    /* Diese Methode erstellt einen Array der die Nachbarn (also Einsen in den acht angrenzenden Stellen) einer jeden
    Stelle zählt und ihr genau diesen Wert zuweist. Beispiel: Stelle [1][1] hat 3 Nachbarn, also erhält Stelle [1][1]
    den Wert 3. Diese Werte werden im Array neighborCount abgelegt.*/
    public static int[][] neighborArr(int[][] preGen) {
        int[][] neighborCount = new int[preGen.length][preGen.length];

        /* Auch hier wieder Stqart bei i/j = 1 und Ende bei i/j < Arraylänge - 1, da wir immer noch den Rahmen aus
        Nullen beachten müssen.*/
        for (int i = 1; i < preGen.length -1; i++){
            for (int j = 1; j < preGen.length -1; j++){

                /* Jede Stelle hat am Anfang 0 Nachbarn. dann werden mit k und l neun Stellen auf Einsen geprüft:
                Die Stelle selbst und jede, die angrenzt (auch diagonal). Für jede gefundene 1 erhöht sich neighbors */
                int neighbors = 0;
                for (int k = -1; k < 2; k++){
                    for (int l = -1; l < 2; l++) {
                        if (preGen[i + k][j + l] == 1){ neighbors++;}

                    }
                }
                /* Da die Stelle selbst mitgeprüft wurde, aber keine Zelle zu sich selbst benachbart ist, muss der
                Wert der Stelle selbst vom Endergebnis abgezogen werden. Dann erhält die Stelle die Anzahl ihrer
                Nachbarn als Wert zugewiesen. */
                neighbors -= preGen[i][j];
                neighborCount[i][j] = (neighbors);
            }
        }
        // Die Methode nextGen wird als return aufgerufen.
        return nextGen(neighborCount, preGen);

    }

    public static void  main(String [] args){
        if (args.length != 2) {
            //Fehler und Abbruch wenn Eingabeparameter nicht zwei sind.
            System.err.println("Erwarte zwei Argumente: int double");
            System.exit(-1);
        }
        // map speichert die gewünschte Größe des Spielfelds, p die Wahrscheinlichkeit lebender Zellen.
        int map = 0;
        double p = 0;

        // Standard try catch.
        try{
            map = Integer.parseInt(args[0]);
            p = Double.parseDouble(args[1]);
            System.out.println("Größe der Map: " + map + "*" + map);
            System.out.println("Wahrscheinlichkeit von Leben: " + p);
        } catch (NumberFormatException e){
            System.err.println("Syntaxfehler in Zahlendarstellung");
            System.exit(-1);
        }

        /* gen ist Array für die erste Generation von Zellen. Es hat Dimensionen von n+2, also eine Art "Rahmen" von
        Nullen, da dies nachher in der Methode zur Bestimmung der Anzahl der Nachbarn notwendig ist.
        Deshalb beginnt i bei 1 und geht bus gen.length -1.
        Es kann nur die Werte 1 oder 0 geben. 1 steht für lebendige Zelle, 0 für eine freie Stelle. Die Einsen werden
        in der folgenden Schleife zufällig generiert, der Rest ist standardmäßig mit Nullen gefüllt.*/
        int [][] gen = new int[map+2][map+2];

        for (int i = 1; i < gen.length -1; i++){
            for (int j = 1; j < gen.length -1; j++){
                /* Für jede Stelle im Array wird eine Zufallszahl zwischen 0 und 1 "pTreshold" gebildet.
                Ist p größer gleich diesem Schwellenwert wird an der Stelle eine 1, also eine Zelle abgelegt.
                */
                double pTreshold = Math.random();
                if (pTreshold <= p){
                    gen[i][j] = 1;
                }
            }
        }

        /* roundCounter ist für die Zählung der Anzahl ausgegebener Generation da. Die Anzahl der ausgegebenen
        Generationen kann beliebig angepasst werden.
        Nachdem das Feld gen ausgegeben wurde wird es zu seinem Nachfolger, der mit neighborArr berechnet wird*/
        int roundCounter = 1;
        while (roundCounter <= 20 ){

            System.out.println("Runde" + roundCounter + ":");
            printField(gen);
            System.out.println();
            gen = neighborArr(gen);
            System.out.println();
            roundCounter++;
        }
    }
}
