package Tut04;

import java.io.*;

public class Markov {
    //Definition des Alphabetes:
    static char[] alphabet = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',' '};
    static char[] alphabetGross = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z', ' '};
    public static void main (String[]args) {

        //Erstellen der Matrix zur Darstellung der Markov-Ketten
        String speicherpfad = args[0];          //Speicherpfad der zu analysierenden Textdatei
        String text = dateiLesen(speicherpfad);
        text = stringFiltern(text);
        double[][] matrix = zustandsuebergaengeZaehlen(text);
        matrix = matrixNormalisieren(matrix, alphabet.length);

        //Generieren von Text basierend auf der Matrix
        int textLaenge = 100;
        StringBuilder generierterText = new StringBuilder();
        int neuerChar = (int) (27*Math.random());
        generierterText.append(alphabet[neuerChar]);

        for (int i = 0; i < textLaenge; i++) {
            //basierend auf dem vorheriegen neuerChar und der Matrix wird ein neuer generiert
            neuerChar = naechtenBuchstabenGenerieren(matrix[neuerChar]);
            generierterText.append(alphabet[neuerChar]);
        }

        System.out.println(generierterText);
    }

    /**
     *
     * @param dateipfad Ordnerpfad aus dem die Datei gelesen werden soll
     * @return Dateinhalt als zusammengefasster String
     */
    public static String dateiLesen(String dateipfad) {
        try {
            File datei = new File(dateipfad);
            FileReader fr = new FileReader(datei);
            BufferedReader br = new BufferedReader(fr);     //Ermöglicht effizienteres Lesen durch Nutzen eines Puffers
            StringBuilder text = new StringBuilder();
            String st;
            //Innerhalb der while-Bedingung wird st mit der nächsten Zeile gefüllt und auf Inhalt überprüft
            while ((st = br.readLine()) != null) {
                text.append(st);
            }
            return String.valueOf(text);
        } catch (IOException fileNotFoundException) {
            System.err.println("Datei konnte nicht gefunden werden!");
            System.exit(1);                         //Fehler, der bekannter Weise auftreten kann
        }
        return "";
    }

    /**
     *
     * @param textStr Eingabetext als String
     * @return text als String ohne zulässige Zeichen
     */
    public static String stringFiltern(String textStr) {
        StringBuilder text = new StringBuilder();
        text.append(textStr);
        boolean charGueltig;

        /* Da mit jedem Löschen eines unzulässigen chars aus text sich dessen Länge um Eins reduziert, muss die selbe
        Stelle nocheinmal überprüft werden (deshalb i--)
         */
        for (int i = 0; i < text.length(); i++) {
            charGueltig = false;
            char charAusText = text.charAt(i);

            for (int j = 0; j < alphabet.length; j++) {
                //Bei Übereinstimmung des chars mit dem Alphabet bleibt er unbelassen
                if (charAusText == alphabet[j]) {
                    charGueltig = true;
                    break;
                }
                /*Bei Übereinstimmung des chars mit einem Großbuchstaben aus dem Alphabet wird zu mit
                dem entsprechenden Kleinbuchstaben ersetzt.
                 */
                if (charAusText == alphabetGross[j]) {
                    text.replace(i, i + 1, String.valueOf(alphabet[j]));
                    charGueltig = true;
                    break;
                }
            }
            if (!charGueltig) {
                text.deleteCharAt(i);
                i--;
            }
        }

        return text.toString();
    }

    /**
     *
     * @param gesucht char, welcher im Alphabet gefunden werden soll
     * @return index im Alphabet; -1, wenn nicht gefunden
     */
    public static int indexInAlphabetVon(char gesucht) {
        for (int i = 0; i < alphabet.length; i++) {
            if (alphabet[i] == gesucht) {
                return i;
            }
        }
        return -1;
    }

    /**
     *
     * @param text Eingabetext als String, der nur aus chars besteht, die im @alphabet vorhanden sind
     * @return matrix, die die absolute Verteilung der chars und dessen Folgechars aus Text angibt. Hierbei enpricht die
     *      x-Achse dem aktuellem char und y-Achse dem Folgechar
     */
    public static double[][] zustandsuebergaengeZaehlen(String text) {
        double[][] matrix = new double[alphabet.length][alphabet.length]; //erster Index: aktueller Wert; zweiter Index: Folgewert
        for (int i = 0; i < (text.length() - 1); i++) {     //laenge - 1, da letzer car nicht vergleichen werden kann
            matrix[indexInAlphabetVon(text.charAt(i))][indexInAlphabetVon(text.charAt(i + 1))] += 1;
        }
        return matrix;
    }

    /**
     *
     * @param matrix matrix, die die absolute Verteilung der chars und dessen Folgechars aus Text angibt
     * @param leangeAlphabet Länge des genutzten Alphabetes
     * @return  matrix, die die Markovketten darstellt.
     */
    public static double[][] matrixNormalisieren(double[][] matrix, int leangeAlphabet) {
        double summe;
        double kontrollsumme;
        for (int i = 0; i < leangeAlphabet; i++) {
            summe = 0.0;
            kontrollsumme = 0.0;
            //Bilden der Summe aller Veknüfungen des Elementes an der Stelle i in der matrix
            for (int j = 0; j < leangeAlphabet; j++) {
                summe += matrix[i][j];
            }
            //Bilden der relativen Anteile jeder Verknüpfung and der Summe aller Verknüfungen in der Matrix
            for (int j = 0; j < leangeAlphabet; j++) {
                matrix[i][j] /= summe;
                kontrollsumme += matrix[i][j];
            }
            if (kontrollsumme < 1) {
                matrix[i][leangeAlphabet - 1] += 1 - kontrollsumme; //Ausgleich von Rundungsfehlern
            }
        }
        return matrix;
    }

    /**
     *
     * @param row Reihe aus der matrix der Markov-Ketten
     * @return Index eines zufälligen Buchstaben im Alphabet unter Berücksichtigung ihrer Wahrscheinlichkeitsverteilung
     */
    public static int naechtenBuchstabenGenerieren(double[] row) {
        double pNaechsterChar = Math.random();  //p entspricht hier in der Namensgebung Wahrscheinlichkeit
        double summeP = 0.0;
        for (int i = 0; i < (row.length); i++) {
            summeP += row[i];
            if (summeP >= pNaechsterChar) {
                return i;
            }
        }
        return -1;
    }

}