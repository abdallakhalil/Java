package Tut04;

import java.util.Arrays;

public class Sudoku {

    /**
     * @param sudoku Matrix eines Sudoku
     * @return boolean (true bei gültigen Zeilen entsprechend der Sudoku-Regeln)
     */
    public static boolean fuerZeilen(int[][] sudoku) {

        int[] abgleichArray = {1, 2, 3, 4, 5, 6, 7, 8, 9}; //speichert alle notwendigen Werte pro Zeile
        int[] zeilenArray = new int[9];

        /*
        zeilenArray werden die Werte je einer Zeile aus dem Sudoku zugewiesen und
        in sortierter Form auf Übereinstimmung mit abgleichArray geprüft.
         */
        for (int zeile = 0; zeile < 9; zeile++) {
            for (int spalte = 0; spalte < 9; spalte++) {
                zeilenArray[spalte] = sudoku[zeile][spalte];
            }
            Arrays.sort(zeilenArray);
            if (!(Arrays.equals(abgleichArray, zeilenArray))) {
                return false;
            }
        }
        return true;
    }

    /**
     * @param sudoku Matrix eines Sudoku
     * @return boolean (true bei gültigen Spalten entsprechend der Sudoku-Regeln)
     */
    public static boolean fuerSpalten(int[][] sudoku) {
        //gleiches Vorgehen wie bei "fuerZeilen()"

        int[] abgleichArray = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int[] spalteArray = new int[9];


        for (int spalte = 0; spalte < 9; spalte++) {
            for (int zeile = 0; zeile < 9; zeile++) {
                spalteArray[zeile] = sudoku[spalte][zeile];
            }
            Arrays.sort(spalteArray);
            if (!(Arrays.equals(abgleichArray, spalteArray))) {
                return false;
            }
        }
        return true;
    }

    /**
     * @param sudoku Matrix eines Sudoku
     * @return boolean (true bei gültigen UnterMatrizen entsprechend der Sudoku-Regeln)
     */
    public static boolean fuerUnterMatrizen(int[][] sudoku) {

        int[] abgleichArray = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int[] zeilenArray = new int[9];
        int counter = 0;

        /*
        Mit der y- und x- Schleife wird jede Untermatrix einmal addressiert.
        Die i- und j- Schleife liefern entsprechende Offsets: j für x; i für y
         */
        for (int y = 0; y < 9; y+=3) {
            for (int x = 0; x < 9; x+=3) {
                for (int i = 0; i < 3; i++) {
                    for (int j = 0; j < 3; j++) {
                        zeilenArray[counter] = sudoku[x+j][y+i];
                        counter++;
                    }
                }
                Arrays.sort(zeilenArray);
                if (!(Arrays.equals(abgleichArray, zeilenArray))) {
                    return false;
                }
                counter = 0;
            }
        }
        return true;
    }

    /**
     * @param sudoku Matrix eines Sudoku
     * @return (true bei gültigen Sudoku entsprechend der Sudoku-Regeln)
     */
    public static boolean isValidSudokuSolution(int[][] sudoku) {
        return fuerZeilen(sudoku)  &&  fuerSpalten(sudoku)  &&  fuerUnterMatrizen(sudoku);
    }

    public static void main(String[] args) {

        int[][] sudokuGueltig = {
                {5,3,4,6,7,8,9,1,2},
                {6,7,2,1,9,5,3,4,8},
                {1,9,8,3,4,2,5,6,7},
                {8,5,9,7,6,1,4,2,3},
                {4,2,6,8,5,3,7,9,1},
                {7,1,3,9,2,4,8,5,6},
                {9,6,1,5,3,7,2,8,4},
                {2,8,7,4,1,9,6,3,5},
                {3,4,5,2,8,6,1,7,9},
        };
        int[][] sudokuUngueltig = {
                {5,3,4,6,7,8,8,1,2},
                {6,7,2,1,9,5,3,4,8},
                {1,9,8,3,4,2,5,6,7},
                {8,5,9,7,6,1,4,2,3},
                {4,2,6,8,5,3,7,9,1},
                {7,1,3,9,2,4,8,5,6},
                {9,6,1,5,4,7,2,8,4},
                {2,8,7,4,1,9,6,3,5},
                {3,4,5,2,8,6,1,7,9},
        };

        /*
        System.out.println(fuerSpalten(sudokuGueltig));
        System.out.println(fuerZeilen(sudokuGueltig));
        System.out.println(fuerUnterMatrizen(sudokuGueltig));
        System.out.println(isValidSudokuSolution(sudokuGueltig));
        */

        if (isValidSudokuSolution(sudokuGueltig)) {
            System.out.println("Die Eingabe ist ein gueltiges Sudoku.");
        }
        else {
            System.out.println("Die Eingabe ist ein ungueltiges Sudoku.");
        }

    }

}