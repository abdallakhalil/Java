package Tut02;
public class Permutations {
}
