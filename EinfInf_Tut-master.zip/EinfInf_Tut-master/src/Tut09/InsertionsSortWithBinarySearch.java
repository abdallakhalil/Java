package Tut09;

import java.util.Arrays;

public class InsertionsSortWithBinarySearch {
    static long sumNormalTime = 0;
    static long sumBinaryTime = 0;

    /**
     * Implementierung von Insertionsort ohne die binäre Suche.
     * insertionSort sortiert ein Array.
     * @param a Array aus Integerwerten, das mit Insertionsort sortiert werden soll.
     */
    public static void insertionSort(int[] a) {
        int n = a.length;

        for (int i = 1; i < n; i++) {

            int x = a[i];
            int j;

            // Einfügeposition finden und alle Einträge um den Index 1 verschieben
            for (j = i; j > 0 && a[j - 1] > x; j--) {
                a[j] = a[j - 1];
            }

            // Setze den Wert, der eingefügt werden soll, an die zuvor freigemachte Stelle im Array
            a[j] = x;
        }
    }

    /**
     * Implementierung von Insertionsort mit binärer Suche.
     * insertionSortWithBinarySearch sortiert ein Array unter Verwendung der binären Suche zum Finden der Einfügestelle.
     * @param a Array aus Integerwerten, das sortiert werden soll.
     */
    public static void insertionSortWithBinarySearch(int[] a) {
        int n = a.length;

        for (int i = 1; i < n; i++) {

            int x = a[i];
            int position;
            int j = i -1;

            // Ermitteln der Position der Einfügestelle
            position = binarySearch(a, 0, j, x);

            // Verschieben aller Einträge um den Index 1
            while (j >= position) {
                a[j+1] = a[j];
                j--;
            }

            // Setze den Wert, der eingefügt werden soll, an die zuvor freigemachte Stelle im Array
            a[j+1] = x;
        }
    }

    /**
     * Binäre Suche zum Ermitteln der Einfügeposition
     * @param a Array, das sortiert wird
     * @param l Linke Grenze
     * @param r Rechte Grenze
     * @param x Gesuchter Wert
     * @return Index, an der der Wert x eingefügt werden soll
     */
    public static int binarySearch(int[] a, int l, int r, int x) {
        // Wenn die Grenzen aufeinadertreffen erfolgt spezielle Abfrage
        if (r <= l) {
            // Fall 1. Wert an linker Grenze ist kleiner als gesuchter Wert -> linke Grenze + 1 ist Einfügeposition
            if (a[l] < x) return l+1;
            // Wenn nicht Fall 1 ist die linke Grenze die Einfügeposition
            else return l;
        }

        int m = (l + r) / 2;

        // Wenn der mittlere Wert aus a dem gesuchten Wert entspricht wird x rechts der Mitte eingeordnet
        if (x == a[m]) return m+1;

        // Wenn x kleiner als mittlerer Wert wird, auf der linken Seite weitergesucht
        if (x < a[m]) return binarySearch(a, l, m - 1, x);

        // Ist größer als mittlerer Wert, wird auf der rechten Seite weitergesucht
        else return binarySearch(a, m + 1, r, x);
    }


    /**
     * Beide Sortierverfahren werden durchlaufen und sortieren dabei zwei gleiche Arrays.
     * @param scope Zahlenbereich der Werte (von 0 bis scope)
     * @param arrLength Länge des Arrays, das sortiert werden soll
     */
    public static void runBothSortingAlgorithms(int scope, int arrLength) {
        int[] insertionNormalArray = new int[arrLength];
        int[] insertionBinaryArray;
        long startTime = 0;

        // insertionNormalArray wird mit Integerwerten befüllt
        for (int i = 0; i < arrLength; i++) {
            insertionNormalArray[i] = (int) (Math.random() * scope);
        }

        // Die Werte aus insertionNormalArray werden in das insertionBinaryArray kopiert,
        // damit beide Verfahren auf der gleichen Grundlage arbeiten
        insertionBinaryArray = Arrays.copyOf(insertionNormalArray, arrLength);

        // Messung der Zeit mit nano.Time()
        startTime = System.nanoTime();
        insertionSort(insertionNormalArray);
        // Zeit pro Durchlauf wird aufaddiert, um später ausgegeben zu werden
        sumNormalTime += System.nanoTime() - startTime;

        startTime = System.nanoTime();
        insertionSortWithBinarySearch(insertionBinaryArray);
        sumBinaryTime += System.nanoTime() - startTime;

        // Falls die Arrays voneinander abweichen, wird eine Fehlermeldung ausgegeben
        if (!(Arrays.equals(insertionNormalArray, insertionBinaryArray))) {
            System.err.println("FEHLER: Die Felder sind ungleich!");
            System.exit(-1);
        }
    }

    public static void main(String[] args) {
        int scopeOfNumbers = 10000;
        int arrayLength = 10000;
        int numberOfRuns = 10000;

        // Beide Sortierverfahren werden "numberOfRuns" oftmal durchlaufen
        for (int i = 0; i < numberOfRuns; i++) {
            runBothSortingAlgorithms(scopeOfNumbers, arrayLength);
        }

        System.out.println("Für " + numberOfRuns + " Durchläufe brauchten die Sortieralgorithmen: \n");

        // Div durch 1000 für Mikrosekunden; div durch 1.000.000 für Millisekunden
        System.out.println("Ohne Binäre Suche: " + sumNormalTime / 1000000 + " ms");
        System.out.println("Mit Binärer Suche: " + sumBinaryTime / 1000000 + " ms");

        /**
         * Was ist uns aufgefallen?
         *
         * Bei 10.000 Durchläufen und einer Array-Länge von 10.000 ist die Binäre-Varinate immer noch langsamer als
         * die normale Variante. Wahrscheinlich liegt das daran, dass die Verwendung der binären Variante
         * nur sinnvoll ist, wenn man an Vergleichen sparen möchte. Die Implementierung der binären Suche
         * benötigt dennoch die gleiche Anzahl an Vertauschungen ( n^2/8 Vertauschungen).
         */
    }
}
