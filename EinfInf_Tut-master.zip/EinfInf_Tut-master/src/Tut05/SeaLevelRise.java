package Tut05;


public class SeaLevelRise {

    public static void main(String[] args) {
        //Einlesen und Überprüfen der Argumente des Höhenprofils
        if (args.length == 2 || args.length == 3) {
            int[] hoehenprofil;
            try {
                hoehenprofil = new int[args[1].length()];
                for (int i = 0; i < hoehenprofil.length; i++) {
                    hoehenprofil[i] = Integer.parseInt(args[1].substring(i, i+1)); //i-te Stelle von args[0]
                }
            }
            catch (NumberFormatException e) {
                System.err.println("Bitte giben Sie im Hoehenprofil nur natuerliche Zahlen an");
                hoehenprofil = new int[0];
                System.exit(-1);
            }

            //Mit optionalem 3. Argument wird das hoehenprofil bei Entprechendem Meeresanstieg ueber NN ausgegeben
            //(Aufgabe 3)
            if (args.length == 3) {
                try {
                    if (Integer.parseInt(args[2]) > 0 || Integer.parseInt(args[2]) < 9) {
                        hoehenprofilNachAnsteigAusgeben(hoehenprofil, Integer.parseInt(args[2]));
                    }
                }
                catch (NumberFormatException e) {
                    System.err.println("Das Argument das Meerwasseranstieges muss eine natürliche Zahl <= 9 sein!");
                }
            }


            //Ausführen des entsprehenden Ausrufes
            if (args[0].equals("groundwater")) {
                System.out.println(args[1]);
            }
            else  if (args[0].equals("seawater")) {
                System.out.println(seawater(hoehenprofil));
            }
            //Fehlermeldungen für sonstige falsche Parameter
            else {
                System.err.println("Bitte rufen sie entweder groundwater oder seawater auf");
                System.exit(-1);
            }
        }
        else {
            System.err.println("Bitte rufen sie entweder groundwater oder seawater sowie ein gueltiges Hoehenprofil auf");
            System.exit(-1);
        }
    }

    /**
     *
     * @param hoehenprofil Höhenprofil über NN
     * @return Reihenfolge der Überflutungen bei einem schrittweisen Anstieg des Meeresspiegels ohne Grundwasseranstieg
     */
    public static String seawater(int[] hoehenprofil) {
        //Prüfen auf Meer
        boolean istMeer = false;
        for (int hoeheI : hoehenprofil) {
            if (hoeheI == 0) {
                istMeer = true;
                break;
            }
        }

        if (istMeer && hoehenprofil.length > 3) {
            //Ermitteln der Reihenfolge der Überflutungen
            int groessterRechts = 0;
            int groessterLinks = 0;
            for (int i = 0; i < hoehenprofil.length; i++) {
                if (hoehenprofil[i] != 0) {
                    /*
                    Wenn hoehenprofil[i] kleiner als der höchte Wert links und rechts davon ist, der nicht durch ein
                    Meer getrennt ist, so wird hoehenprofil[i] auf den kleineren der Beiden Werte gesetzt.
                     */

                    //Finden des groessten rechten nicht vom Meer getrennten Wert   //todo: in der Abgabe sind links und rechts im Kommentar vertauscht
                    for (int j = i; j < hoehenprofil.length; j++) {
                        if (hoehenprofil[i] < hoehenprofil[j] && groessterRechts < hoehenprofil[j]) {
                            groessterRechts = hoehenprofil[j];
                        }
                        else if (hoehenprofil[j] == 0){
                            break;
                        }
                    }
                    //Finden des groessten linken nicht vom Meer getrennten Wert
                    for (int j = i; j >= 0; j--) {
                        if (hoehenprofil[i] < hoehenprofil[j] && groessterLinks < hoehenprofil[j]) {
                            groessterLinks = hoehenprofil[j];
                        }
                        else if (hoehenprofil[j] == 0){
                            break;
                        }
                    }
                    //Vergleichen der Werte
                    if (hoehenprofil[i] < groessterLinks && hoehenprofil[i] < groessterRechts) {
                        hoehenprofil[i] = Math.min(groessterLinks, groessterRechts);
                    }
                    groessterLinks = 0;
                    groessterRechts = 0;
                }
            }
        }

        //Erstellen des Rueckgabestrings
        StringBuilder rueckgabe = new StringBuilder();
        for (int reheifolgeI : hoehenprofil) {
            rueckgabe.append(reheifolgeI);
        }
        return rueckgabe.toString();
    }

    /**
     * Gibt das Höhenprofil über NN nach Anstig definiert durch anstiegt des Meeres, bzw. Grundwasserspiegels aus
     * @param hoehenprofil Höhenprofil über NN
     * @param anstieg Höhe des Anstieges des Pegels
     */
    public static void hoehenprofilNachAnsteigAusgeben(int[] hoehenprofil, int anstieg) {
        //Ermitteln des hoehenprofils über Normal NUll nach dem geforderten Meerwasseranstig
        for (int i = 0; i < hoehenprofil.length; i++) {
            hoehenprofil[i] -= anstieg;
            if (hoehenprofil[i] < 0) {
                hoehenprofil[i] = 0;
            }
        }

        //Ermitteln des höchsten Wertes
        int hoechteHoehe = 0;
        for (int aktuellerWert : hoehenprofil) {
            if (hoechteHoehe < aktuellerWert) {
                hoechteHoehe = aktuellerWert;
            }
        }

        //Ausgabe des 2D Hoehenprofils
        for (int aktuelleAusgabeHoehe = hoechteHoehe; aktuelleAusgabeHoehe > 0; aktuelleAusgabeHoehe--) {
            for (int hoeheI : hoehenprofil) {
                if (hoeheI >= aktuelleAusgabeHoehe) {
                    System.out.print('*');
                } else {
                    System.out.print(' ');
                }
            }
            System.out.println();
        }
        System.out.print("\nReihenfolge der Überflutungen bei einem schrittweisen Anstieg des Meeresspiegels " +
                "ohne Grundwasseranstieg: ");
    }
}


