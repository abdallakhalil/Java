package Tut05;
import java.text.DecimalFormat;

public class Percolation {

    /**
     * Diese Methode ist zuständig für die Erstellung der zu testenden Arrays. Hierbei wird das Array mit den Werten
     * 'true' und 'false' gefüllt. Die Wahrscheinlichkeit der Häufigkeit von 'false' wird durch p bestimmt.
     * @param x Länge des zu erstellenden Arrays
     * @param y Breite des zu erstellenden Arrays
     * @param p Blockade-Wahrscheinlichkeit
     * @return 'perkArray' gibt ein zweidimensionales boolean Array zurück.
     */
    public static boolean[][] erstelleNeuesArray(int x, int y, double p){

        //Array wird initialisiert
        boolean[][] perkArray = new boolean[x][y];

        // Für jede Stelle im Array erhält 'schwellwert' einen zufälligen Wert zwischen 0 und 1.
        // Wenn schwellwert <= p, dann ist perArray[i][j] = 'false', sonst 'true'.
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                double schwellwert = Math.random();
                perkArray[i][j] = !(schwellwert <= p);
            }

        }
        return perkArray;
    }

    /**
     * Diese Methode erstellt ein Array 'perkArrayMarkiert' mit den Dimensionen von 'perkArray' und ruft für jede
     * Stelle [0][j] in perkArray die Methode 'penetrationTest' auf.
     * Anschließend wird auf Perkolation getestet.
     * @param perkArray stellt das Medium dar, das auf Perkolation getestet werden soll.
     * @return Wenn Perkolation gefunden wurde wird 'true' zurückgegeben. Wenn nicht, dann 'false'.
     */
    public static boolean perkoliert (boolean[][] perkArray){

        boolean[][] perkArrayMarkiert = new boolean[perkArray.length][perkArray[0].length];

        //Für jede Stelle perkArray[0][j] (die erste Zeile) Aufruf von 'penetrationTest'
        for (int j = 0; j < perkArray[0].length; j++) {
            penetrationTest(perkArray, perkArrayMarkiert, 0, j);
        }

        // Um zu testen ob das Medium perkoliert, zählt man die Anzahl blockierter Stellen in der untersten Zeile.
        // Wenn sie alle blockiert (also false) sind, ist das Medium nicht durchlässig.
        int blockierteStellen = 0;
        for (int j = 0; j < perkArrayMarkiert[0].length; j++) {
            if (!perkArrayMarkiert[perkArrayMarkiert.length -1][j]){
                blockierteStellen++;
            }
        }

        //Rückgabe 'true' wenn nicht jede Stelle in der letzten Zeile von 'perkArrayMarkiert' == 'false'
        return blockierteStellen != perkArrayMarkiert[0].length;
    }

    /**
     * Diese Methode implementiert den Eigentlichen Algorithmus, der auf Perkolation testet. Dafür wird durch Rekursion
     * Schritt für Schritt jede erreichbare Stelle in 'perkArrayMarkiert' mit 'true' markiert.
     * Bedingungen, dass dies geschieht, sind: i und j liegen in den Dimensionen des Arrays, die Stelle wurde nicht
     * bereits markiert und in 'perkArray' ist die Stelle nicht 'false' (dies entspräche einer nicht durchlässigen
     * Stelle). Sind diese Bedingungen erfüllt, wird von [i][j] ausgehend weiter nach freien Stellen gesucht. Dies
     * geschieht nach oben, unten, links und rechts.
     * @param perkArray Das auf Perkolation zu testende Array.
     * @param perkArrayMarkiert Die Kopie von 'perkArray', in der jetzt die Werte verändert werden sollen.
     * @param i Die Zeile der Position in 'perkArray' bzw. 'perkArrayMarkiert'
     * @param j Die Spalte der Position in 'perkArray' bzw. 'perkArrayMarkiert'
     */
    public static void penetrationTest(boolean[][] perkArray, boolean[][] perkArrayMarkiert, int i, int j){

        //Bedingungen, die zu keiner Veränderung in perkArrayMarkiert führen:
        //1. Wenn [i][j] außerhalb des Arrrays liegt, soll nicht getestet werden.
        if (i < 0 || i >= perkArray.length || j < 0 || j >= perkArray[0].length) return;

        //2. Wenn perkArray[i][j] false ist, also undurchlässig, oder perkArrayMarkiert[i][j] bereits mit true, also
        //  als durchlässig markiert wurde.
        if (!perkArray[i][j] || perkArrayMarkiert[i][j]) return;

        // Die Stelle wird als durchlässig markiert.
        perkArrayMarkiert[i][j] = true;

        //Es wird nach links,rechts, oben und unten weitergesucht.
        penetrationTest(perkArray, perkArrayMarkiert, i + 1, j); // unten
        penetrationTest(perkArray, perkArrayMarkiert, i, j + 1); // rechts
        penetrationTest(perkArray, perkArrayMarkiert, i, j - 1); // links
        penetrationTest(perkArray, perkArrayMarkiert, i - 1, j); // oben
    }

    /**
     * @param x Länge des Arrays
     * @param y Breite des Arrays
     * @param p Blockade-Wahrscheinlichkeit
     * @param n Anzahl der Durchläufe (= Anzahl der auf Perkolation zu testenden Arrays)
     * Diese Methode ist für die Durchführung von n Durchläufen zuständig. In jedem Durchlauf wird ein neues Array
     * mit konstanter Blockade-Wahrscheinlichkeit p auf Perkolation geprüft.
     * Ausgabe: Dimension der Arrays, Blockade-Wahrscheinlichkeit p und Anzahl Arrays mit Perkolation von n Durchläufen.
     */
    public static void perkMitKonstantp (int x, int y, double p, int n){

        //Es wird n-mal ein neues Array erstellt, wenn dieses perkoliert erhöht sich Zähler 'durchlaessigeArrays' um eins.
        int durchlaessigeArrays = 0;
        for (int i = 0; i < n; i++) {
            if (perkoliert(erstelleNeuesArray(x,y,p))) {
                durchlaessigeArrays++;
            }
        }

        //Ausgabe der relevanten Rahmenbedingungen und Durchlaufergebnisse.
        System.out.println("Dimension der Testmedien: " + x + " x " + y);
        //System.out.println("Blockade-Wahrscheinlichkeit " + p*100 + "%");
        System.out.println("Blockade-Wahrscheinlichkeit " + Math.round(p * 1000.00)/10.00 + "%");
        //Math.round((p + 0.01)* 100.00)/100.00
        //System.out.println("Blockade-Wahrscheinlichkeit " + p);
        System.out.println("Perkolation tritt auf bei "+ durchlaessigeArrays + " von " + n + " getesteten Medien.\n");
    }

    /**
     * Methode für die Bonusaufgabe. Ruft zunächst die Methode 'perkMitKonstantp' auf. Danach rekursiver Aufruf mit
     * p + 0.01 (kann manuell geändert werden) bis p == 1. Somit erhalten wir insgesamt ((1-p)/0.01) * n Durchläufe.
     * @param x Länge der zu testenden Arrays
     * @param y Breite der zu testenden Arrays
     * @param p Blockade-Wahrscheinlichkeit. Wird verändert.
     * @param n Anzahl der Durchläufe (pro p)
     */
    public static void permpWachsend (int x, int y, double p, int n){
        perkMitKonstantp(x,y,p,n);
        if (p < 1) permpWachsend(x, y, p + 0.01 , n);

    }

    /**
     * @param x Länge des Arrays
     * @param y Breite des Arrays
     * @param p Blockade-Wahrscheinlichkeit
     * Diese Methode soll ein Array 'ausgabeArray' entsprechend der Eingabeparameter ausgeben.
     * Zusätzlich gibt sie aus, ob in 'ausgabeArray' Perkolation gefunden wurde oder nicht.
     */
    public static void arrayAusgeben (int x, int y, double p){

        boolean[][] ausgabeArray = erstelleNeuesArray(x,y,p);

        //Ausgabe ob Perkolation oder nicht.
        System.out.println("Beispiel für getestetes Medium:");
        if (perkoliert(ausgabeArray)){
            System.out.println("Perkolation gefunden.");
        }
        else System.out.println("Keine Perkolation gefunden.");

        //Standard-Ausgabe für zweidimensionales Array.
        // Für [i][j] == false und [i][j] == true gibt es je zwei gleiche Zeichen als Ausgabe.
        for (int i = 0; i < ausgabeArray.length; i++) {
            for (int j = 0; j < ausgabeArray[0].length; j++) {
                if (!ausgabeArray[i][j]){
                    System.out.print("\u2588\u2588");
                }
                else System.out.print("\u2591\u2591");

            }
            System.out.print("\n");

        }

    }

    public static void main(String[] args){

        //Prüft die Anzahl der Parameter und beendet Programm wenn es nicht vier sind.
        if (args.length != 4){
            System.err.println("Eingabe Fehlerhaft.");
            System.exit(1);
        }

        //Deklaration der benötigten Variablen.
        int x = 0, y = 0, n = 0;
        double p = 0;

        //Standard try/catch für alle vier Eingabeparameter.
        try{
            x = Integer.parseInt(args[0]);
            y = Integer.parseInt(args[1]);
            p = Double.parseDouble(args[2]);
            n = Integer.parseInt(args[3]);
        } catch (NumberFormatException e){
            System.err.println("Nicht zulässigen Wert gefunden.");
            System.exit(1);
        }

        //Erneute Prüfung der Werte.
        if (x < 1 || y < 1 || p < 0 || p > 1 || n < 1){
            System.err.println("Nicht zulässigen Wert gefunden.");
            System.exit(1);
        }

        //OPTIONAL: für die Ausgabe eines Beispiels. Mehr dazu in der Methode selbst.
        //arrayAusgeben(x,y,p);

        // OPTIONAL: Aufruf der Methode für die Bonusaufgabe:
        //permpWachsend(x,y,p,n);

        //Berechnung der Perkolation von n verschiedenen Medien (Arrays) mit konstanter Blockade-Wahrscheinlichkeit p.
        perkMitKonstantp(x,y,p,n);


    }
}