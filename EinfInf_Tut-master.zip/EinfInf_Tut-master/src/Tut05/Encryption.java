package Tut05;

public class Encryption {
    //todo: Das Programm wurde nie fertiggestellt

    // alphabet ist vorerst nur als globale Variable definiert
    public static char[] alphabet = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

    /**
     * ### ZUR PROGRAMMSTRUKTUR: ###
     * Die Methoden findPosImAlphabet(), rotEncryption() und encryption() dienen der Verschlüsselung.
     * Die Methoden anzahlCharErmittlen(), verteilungPruefen() und decryption() dienen der Entschlüsselung.
     *
     * Die Methoden der Entschlüsselung sind noch nicht fertig und funktionieren im derzeitigen Stand nicht richtig.
     *
     * In der Main-Methode wird erst nach der Anzahl (Länge) der Argumente gefragt. Bei 2 Argumenten wird entweder
     * mit rot13 Verschlüsselt oder ein Text wird Entschlüsselt. Bei 3 Argumenten wird mit
     * einen speziellen Schlüssel (args[1]) ein Text verschlüsselt.
     *
     *
     *              _---|---_
     *         _---|        |---_
     *         |                |
     *     len == 2         len == 3
     *    _-|    |-_            |
     *    |        |            |
     *  enc(13)   dec()       enc(x)
     *
     *  ###
     */

    /**
     * Ermittelt die Position eines Char im Alphabet
     * @param eingabe Char, Teil des Eingabe-Strings
     * @return  int als Index vom Alphabet; Wenn nicht im Alphabet enthalten ist der Wert -1
     */
    public static int findPosImAlphabet(char eingabe){

        for (int i = 0; i < alphabet.length; i++) {

            if (alphabet[i] == eingabe) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Führt die rot-Verschlüsselung für einen Char durch
     * @param schluessel Anzahl der Stellen, um die versetzt werden soll
     * @param eingabe   Char, der verschlüsselt werden soll
     * @return  Gibt einen neuen Char zurück; Wenn der Char nicht Teil des Alphabets ist, wird er selbst zurückgegeben
     */
    public static char rotEncryption(int schluessel, char eingabe){
        int tempValue = 0;

        if (findPosImAlphabet(eingabe) != -1) {

            tempValue = findPosImAlphabet(eingabe) + schluessel;

            if (tempValue < 26) {
                return alphabet[tempValue];
            }
            else {
                return alphabet[(tempValue - alphabet.length)];
            }
        }
        else {
            return eingabe;
        }
    }

    /**
     * Führt die Verschlüsselung für die ganze Eingabe durch
     * @param schluessel Anzahl der Stellen, um die versetzt werden soll
     * @param eingabe String, der als Kommandozeilenparameter übergeben wurde
     * @return Char[], der später ausgegeben wird
     */
    public static char[] encryption(int schluessel, String eingabe){

        eingabe = eingabe.toLowerCase();

        char[] eingabeArray = eingabe.toCharArray();
        char[] ausgabeArray = new char[eingabeArray.length];

        for (int i = 0; i < eingabe.length(); i++) {
            ausgabeArray[i] = rotEncryption(schluessel, eingabeArray[i]);
        }
        return ausgabeArray;
    }

    /**
     * Berechnet die Anzahl für die drei häufigsten Buchstaben
     * @param eingabeArray  Char[], besteht aus alles Char des Eingabestrings
     * @return  int[], enthält die Anzahl, wie oft welcher Buchstabe (von e, n und s) vorkommt
     */
    public static int[] anzahlCharErmittlen(char[] eingabeArray) {
        char[] wichtigeChar = {'e', 'n', 's'};
        int[] anzahlWichtigeChar = new int[wichtigeChar.length];

        for (int i = 0; i < wichtigeChar.length; i++) {
            for (int j = 0; j < eingabeArray.length; j++) {
                if (wichtigeChar[i] == eingabeArray[j]) {
                    anzahlWichtigeChar[i] += 1;
                }
            }
        }
        return anzahlWichtigeChar;
    }

    /**
     * Überprüft, ob e häufiger als n und n häufiger als s vorkommt
     * @param anzahlChar int[], enthält die Anzahl, wie oft welcher Buchstabe (von e, n und s) vorkommt
     * @return boolean, true wenn e häufiger als n und n häufiger als s vorkommt
     */
    public static boolean verteilungPruefen(int[] anzahlChar) {
        boolean istGueltig = false;

        for (int i = 0; i < anzahlChar.length-1; i++) {
            if (anzahlChar[i] > anzahlChar[i+1]) {
                istGueltig =  true;
            } else {
                return false;
            }
        }
        return istGueltig;
    }

    /**
     * Führt die Entschlüsselung durch
     * @param eingabe String, der als Kommandozeilenparameter übergeben wurde
     * @return Char[], der später ausgegeben wird
     */
    private static char[] decryption(String eingabe) {
        eingabe = eingabe.toLowerCase();
        char[] ausgabeArray = new char[eingabe.length()];

        for (int i = 1; i < 27; i++) {

            if (verteilungPruefen(anzahlCharErmittlen(encryption(i, eingabe)))) {
                return encryption(i, eingabe);
            }
        }
        return ausgabeArray;
    }

    /**
     * Bestimmt den Integer des Schlüssels (macht aus rot6 -> (int) 6
     * @param schluesselParam entapricht dem args[1], wenn args.lentgh == 3 ist (z.B. "rot20")
     * @return Integerwert, der dem Schlüssel entspricht
     */
    public static int schluesselErmitteln(String schluesselParam) {
        int schluessel = 0;

        schluesselParam = schluesselParam.replace("rot", "");
        schluessel = Integer.parseInt(schluesselParam);

        return schluessel;
    }

    /**
     * Gibt ein char[] Array im Terminal aus
     * @param ausgabeArray Char[], der ausgegeben werden soll
     */
    public static void arrayAusgabe(char[] ausgabeArray) {
        for (int i = 0; i < ausgabeArray.length; i++) {
            System.out.print(ausgabeArray[i]);
        }
    }


    public static void main(String[] args) {
        String eingabeParam = "";
        String modus = "";
        int schluessel = 0;

        if (args.length == 2) {

            // enc(13) oder dec()
            try {
                modus = args[0];
                eingabeParam = args[1];
            } catch (Exception e) {
                System.out.println("Bitte geben Sie gueltige Parameter ein.");
                System.exit(1);
            }

            if (modus.equals("encrypt")) {
                arrayAusgabe(encryption(13, eingabeParam));
            }
            else if (modus.equals("decrypt")) {
                arrayAusgabe(decryption(eingabeParam));
            }
            else {
                System.out.println("Bitte verwenden Sie den Modus \"encrypt\" oder \"decrypt\".");
            }

        }
        else if (args.length == 3) {

            try {
                schluessel = schluesselErmitteln(args[1]);
                eingabeParam = args[2];

            } catch (Exception e) {
                System.out.println("Bitte geben Sie gueltige Parameter ein.");
                System.exit(1);
            }

            arrayAusgabe(encryption(schluessel, eingabeParam));

        } else {
            System.out.println("Bitte uebergeben Sie zwei bzw. drei Parameter.");
        }
    }
}
