package Tut07;

/**
 * Alle folgenden Klassen erben von CaffeineInfusedBeverage und representieren die verschieden Sorten bzw.
 * die verschiedenen Bohnenarten, die zur Herstellung von Kaffee gebraucht werden. Jede Klasse besitzt eine
 * eigene Beschreibung und einen eigenen Preis.
 */

class Espresso extends CaffeineInfusedBeverage {

    public Espresso() {
        description_ = "Espresso";
    }

    @Override
    public double cost() {
        return 2.5;
    }

    @Override
    public String getDescription() {
        return description_;
    }
}

class CafeLatte extends CaffeineInfusedBeverage {

    public CafeLatte() {
        description_ = "Cafe Latte";
    }

    @Override
    public double cost() {
        return 2.0;
    }

    @Override
    public String getDescription() {
        return description_;
    }
}

class Cappuccino extends CaffeineInfusedBeverage {

    public Cappuccino() {
        description_ = "Cappuccino";
    }

    @Override
    public double cost() {
        return 2.75;
    }

    @Override
    public String getDescription() {
        return description_;
    }
}

class CafeMocha extends CaffeineInfusedBeverage {

    public CafeMocha() {
        description_ = "Cafe Mocha";
    }

    @Override
    public double cost() {
        return 3.5;
    }

    @Override
    public String getDescription() {
        return description_;
    }
}

public class Drinks { }