package Tut07;

class Coffee {

    public static void printInformation(CaffeineInfusedBeverage beverage) {
        System.out.printf(beverage.getDescription() + " (Price: " +  "%.2f EUR)%n", beverage.cost());
    }

    public static void main(String[] args) {
        //testcases
        CaffeineInfusedBeverage espressoWithMilk = new Milk(new Espresso());
        printInformation(espressoWithMilk);

        CaffeineInfusedBeverage coffeeInProgress = new Cappuccino();
        printInformation(coffeeInProgress);

        coffeeInProgress = new Milk(coffeeInProgress);
        printInformation(coffeeInProgress);

        coffeeInProgress = new Sugar(coffeeInProgress);
        printInformation(coffeeInProgress);

        coffeeInProgress = new Foam(coffeeInProgress);
        printInformation(coffeeInProgress);

    }
}