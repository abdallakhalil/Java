package Tut07;

abstract class CaffeineInfusedBeverage {
    String description_;

    public abstract double cost();

    public String getDescription() {
        return description_;
    }
}