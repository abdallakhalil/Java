package Tut07;

abstract class AddOnDecorator extends CaffeineInfusedBeverage {
    CaffeineInfusedBeverage drink_;

    public AddOnDecorator(CaffeineInfusedBeverage drink) {
        drink_ = drink;
    }

    @Override
    public double cost() {
        return drink_.cost();
    }

    @Override
    public String getDescription() {
        return drink_.getDescription();
    }
}
