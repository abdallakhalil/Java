package Tut07;

/**
 * Alle folgenden Klassen erben von AddOnDecorator. Der AddOnDecorator erbt selber von CaffeineInfusedBeverage.
 * Damit stehen die Klassen aus AddOns.java in der Verbungshierachie, allgemein gesagt, eine Ebene tiefer als
 * die Klassen aus Drinks.java.
 * Alle AddOns aus AddOns.java besitzen eine Beschreibung und einen Preis.
 */

class Milk extends AddOnDecorator {

    public Milk(CaffeineInfusedBeverage drink) {
        super(drink);
    }

    @Override
    public double cost() {
        return super.cost() + 0.5;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " with Milk";
    }
}

class Sugar extends AddOnDecorator {

    public Sugar(CaffeineInfusedBeverage drink) {
        super(drink);
    }

    @Override
    public double cost() {
        return super.cost() + 0.25;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " with Sugar";
    }
}

class Foam extends AddOnDecorator {

    public Foam(CaffeineInfusedBeverage drink) {
        super(drink);
    }

    @Override
    public double cost() {
        return super.cost() + 0.5;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " and foamed";
    }
}

class SoyMilk extends AddOnDecorator {

    public SoyMilk(CaffeineInfusedBeverage drink) {
        super(drink);
    }

    @Override
    public double cost() {
        return super.cost() + 1.5;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " with soymilk";
    }
}

class OatMilk extends AddOnDecorator {

    public OatMilk(CaffeineInfusedBeverage drink) {
        super(drink);
    }

    @Override
    public double cost() {
        return super.cost() + 1.5;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " with oat milk";
    }
}

class LactoseFreeMilk extends AddOnDecorator {

    public LactoseFreeMilk(CaffeineInfusedBeverage drink) {
        super(drink);
    }

    @Override
    public double cost() {
        return super.cost() + 0.5;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " with lactose-free milk";
    }
}

class LowFatMilk extends AddOnDecorator {

    public LowFatMilk(CaffeineInfusedBeverage drink) {
        super(drink);
    }

    @Override
    public double cost() {
        return super.cost() + 0.5;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " with low-fat milk";
    }
}

class HazelnutMilk extends AddOnDecorator {

    public HazelnutMilk(CaffeineInfusedBeverage drink) {
        super(drink);
    }

    @Override
    public double cost() {
        return super.cost() + 1.5;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " with hazelnut milk";
    }
}

public class AddOns {}