package Tut06;

/** Diese Klasse ist die Rettungskapsel. Nur durch Flucht in ihr kann das Spiel "gewonnen" werden.
 */
public class SecondRoom  extends Room{

    //Konstruktor führt zur Mutterklasse (Room)
    public SecondRoom(String name) {
        super(name);
    }

    public void getDescription(){
        if (!TextAdventureB.labor.onFire) {
            System.out.println("Du bist in der Rettungskapsel. Wenn es mal brenzlig wird, ist sie deine beste Möglichkeit\n" +
                    "zu entkommen. Es ist eng hier. Durch ein kleines Bullauge siehst du die Sterne." +
                    "\nHoffentlich musst du dich nie hier reinzwängen.");
        }
        else {
            System.out.println("Das Schiff ist verloren. Du wirst verbrennen, wenn du hierbleibst." +
                    "\nDie Rettungskapsel könnte dir das Leben retten. Möchtest du mit ihr das Schiff verlassen?" +
                    "\na) Ja\nb) Nein");
            switch (getUserInput()) {
                case "a" -> {
                    System.out.println("Du schließt die Tür und startest den Autopiloten der Kapsel. Sie " +
                        "entkoppelt sich und fliegt sofort los.\nSekunden später explodiert dein Schiff, du bist " +
                        "inzwischen aber in sicherer Entfernung.\nImmerhin hast du überlebt! Die Rettungskapsel" +
                        "wird dich sicher zur Erde bringen. Glückwunsch " + TextAdventureB.playerName + ", du hast" +
                                    "das Spiel erfolgreich beendet.\n\nEnde des Text Adventures.");
                    System.exit(1);
                }
                case "b" -> {
                    System.out.println("Du entscheidest dich zu bleiben. Das Feuer ist nun auch in Schleuse." +
                            "\nPlötzlich gibt es eine massive Explosion und ein Feuerball verschlingt dich." +
                            "\nWärst du doch geflüchtet! Das wars... \n\nGAME OVER");
                    System.exit(-1);
                }
                default -> {
                    System.out.println("Ungültige Eingabe. Bitte a oder b eingeben und mit Enter bestätigen.");
                    onEntry();
                }
            }
        }
    }
}
