package Tut06;

/** Diese Klasse ist die Schleuse. Hier gibt es ingame nichts zu tun.
 */
public class FifthRoom extends Room {

    //Konstruktor führt zur Mutterklasse (Room)
    public FifthRoom(String name) {
        super(name);
    }

    public void getDescription(){
        System.out.println("Das ist die Schleuse. Sie verbindet die Rettungskapsel mit dem Rest des Raumschiffs.\n" +
                "Nicht sehr spannend.");
    }
}
