package Tut06;

import java.util.Scanner;

/** Die Klasse für die main Methode. Hier werden die Objekte der anderen Klassen erzeugt und der Text der
 * Anfangssequenz wird ausgegeben.
 */
public class TextAdventureB {
    public static String playerName;
    public static boolean hasGun = false;
    public static FirstRoom bruecke = new FirstRoom("Brücke");
    public static Room standort = bruecke;
    public static SecondRoom kapsel = new SecondRoom("Rettungskapsel");
    public static ThirdRoom labor = new ThirdRoom("Labor");
    public static FourthRoom waffenkammer = new FourthRoom("Waffenkammer");
    public static FifthRoom schleuse = new FifthRoom("Schleuse");
    public static Room [] raeume = {bruecke, kapsel, labor, waffenkammer, schleuse };




    public static void main(String [] args){

        Scanner mainScan = new Scanner(System.in);

        System.out.println("Herzlich Willkommen in diesem TextAdventure. \nBevor es losgeht, wie ist dein Name?");
        playerName = mainScan.nextLine();
        System.out.println("Alles klar, " + playerName + ". Los gehts!\n");

        System.out.println("Wir schreiben das Jahr 2452. Du bist ein Weltraumforscher, an Bord deines Raumschiffes in " +
                "den tiefen des Alls.\nDeine letzte Mission war ein voller Erfolg. Sie bestand darin, Lebendproben" +
                " von einem neu entdeckten,\nunerforschten Planeten einzusammeln. Nach der Landung dauerte es nicht " +
                "lang, bis du eine embryonenartige Biomasse\nin einer Höhle fandest. Diese nahmst du mit auf dein Schiff.\n" +
                "Jetzt ist sie sicher verstaut im Labor des Raumschiffs, welches momentan mit knapp 100.000 km/h durchs" +
                " All rast.\nZufrieden und vorfreudig auf die Rückkehr zur Erde sitzt du auf der Kommandobrücke.");
        standort.pressEnter();

        System.out.println("Während du in Gedanken an die Heimat versunken aus dem Fenster starrst, gibt es plötzlich " +
                "einen Knall und eine Erschütterung.\nDas klang nicht gut! Was könnte passiert sein? Es kam \n" +
                "aus der Richtung des Labors...");
        standort.whatToDo();


    }
}
