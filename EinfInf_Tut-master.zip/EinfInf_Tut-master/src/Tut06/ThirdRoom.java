package Tut06;

/** Diese Klasse ist das Labor. Hier befindet sich ein Alien, welches besiegt werden muss. Dafür muss man eine Waffe
 * in der Waffenkammer finden.
 */
public class ThirdRoom extends Room{

    public boolean alienAlive = true;
    public boolean firstTry = true;
    public boolean onFire = false;
    //Konstruktor führt zur Mutterklasse (Room)
    public ThirdRoom(String name) {
        super(name);
    }

    public void onEntry(){
        if (firstTry && alienAlive){
            System.out.println("Verdammt, was ist das denn? Du öffnest die Tür und starrst in die Augen eines Aliens." +
                    "\nEs muss dir auf dem Planeten gefolgt sein und sich unbemerkt an Bord versteckt haben." +
                    "\nDas Alien gibt ein gurgelndes Geräusch von sich und stürzt auf dich zu." +
                    "\nIm letzten Moment schaffst du es, aus dem Labor zu hechten und den Notschalter zu drücken." +
                    "\nDie Tür zum Labor schließt und verriegelt sich. Durch ein Sichtfenster kannst du das " +
                    "\nAlien beobachten, wie es scheinbar wütend gegen die Tür hämmert. Und jetzt?" +
                    "\nDu musst es ausschalten!");
            firstTry = false;

            if (!TextAdventureB.hasGun){
                System.out.println("Aber ohne Waffe hast du keine Chance!" +
                        "\nWas tust du?\na) Kämpfen\nb) Erst eine Waffe suchen");
            }
            else System.out.println("Willst du es bekämpfen?\na) Ja\nb) Nein");

            switch (getUserInput()) {
                case "a" -> fightAlien();
                case "b" -> changeLocation();
                default -> {
                    System.out.println("Ungültige Eingabe. Bitte a oder b eingeben und mit Enter bestätigen.");
                    onEntry();
                }
            }

        }
        else if(alienAlive && !TextAdventureB.hasGun){
            System.out.println("Da ist ein Alien im Labor, bist du sicher dass du eintreten willst?\na) Ja\nb) Nein");
            switch (getUserInput()) {
                case "a" -> fightAlien();
                case "b" -> changeLocation();
                default -> {
                    System.out.println("Ungültige Eingabe. Bitte a oder b eingeben und mit Enter bestätigen.");
                    onEntry();
                }
            }
        }
        else if (alienAlive && TextAdventureB.hasGun){
            System.out.println("Mit deiner Waffe gerüstet stürzt du mutig in den Kampf!");
            pressEnter();
            fightAlien();
        }
        else super.onEntry();
    }

    public void getDescription(){
        System.out.println("Das Labor. Der Ort deiner Forschung. Nach dem Vorfall leider verwüstet. " +
                "\nDas Feuer breitet sich lodernd aus. Überall Fläschchen, Gläser und andere " +
                "\n Behältnisse voll mit Proben, Chemikalien und Experimenten." +
                "\nVieles ist zerbrochen und es riecht sehr seltsam. Außerdem ist alles mit Alienhirn besprenkelt." +
                "\nDu solltest nicht zu lange hierbleiben. Du musst flüchten!");
    }

    public void fightAlien(){
        if (TextAdventureB.hasGun){
            System.out.println("Das Alien stürzt sofort auf dich zu, aber auch du eröffnest direkt das Feuer!" +
                    "\nMit einem gezielten Kopfschuss streckst du es nieder. Reglos bleibt es liegen. Geschafft!");
            alienAlive = false;
            onFire = true;
            pressEnter();
            System.out.println("Während du noch triumphierst, merkst du, was du angerichtet hast." +
                    "\nZwar ist das Alien besiegt, aber ein Schuss hat leider ein Reagenzglas getroffen, welches " +
                    "\nin Flammen aufgegangen ist. Du versuchst, es zu löschen, aber es breitet sich immer" +
                    "\nweiter aus. Du musst fliehen!");
            whatToDo();
        }
        else {
            System.out.println("Als du die Tür öffnest, greift dich das Alien sofort an.\nOhne Waffe bist du leider" +
                    "völlig wehrlos. Nur ein kurzer Augenblick, und es hat dich mit seinen Krallen aufgeschlitzt.\n" +
                    "Schade, das wars...\n\nGAME OVER");
            System.exit(1);
        }
    }
}
