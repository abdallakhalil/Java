package Tut06;

import java.util.Scanner;

/**
 * Die Mutterklasse aller anderen Räume. Hier findet der Wechsel zwischen den Räumen statt, sowie andere Entscheidungen.
 */
public abstract class Room {

    private final String name;

    public void pressEnter(){
        System.out.println("\nDrücke Enter um fortzufahren.");
        Scanner enter = new Scanner(System.in);
        enter.nextLine();
    }

    public void onEntry(){
        System.out.println("Neuer Standort: " + getName());
        whatToDo();
    }

    public abstract void getDescription();

    //Konstruktor mit Name
    public Room (String name){
       this.name = name;
    }

    //Getter für Name
    public String getName() {
        return name;
    }

    //Methode um User Input zu bekommen
    public String getUserInput(){
        Scanner scan = new Scanner(System.in);
        return scan.nextLine();
    }


    public void lookAround(){
        getDescription();
        System.out.println("Möchtest du schauen, ob du etwas nützliches finden kannst?\na) Ja\nb) Nein");
        switch (getUserInput()) {
            case "a" -> searchFor();
            case "b" -> {
                System.out.println("Alles klar.");
                whatToDo();
            }
            default -> {
                System.out.println("Ungültige Eingabe. Bitte a oder b eingeben und mit Enter bestätigen.");
                this.lookAround();
            }
        }
    }

    public void searchFor(){
        System.out.println("Du findest nichts, was nützlich aussieht...");
        pressEnter();
        whatToDo();
    }

    public void whatToDo() {
        System.out.println("Was möchtest du tun?");
        System.out.println("a) Mich umsehen...");
        System.out.println("b) Woanders hingehen!");

        switch (getUserInput()) {
            case "a" -> lookAround();
            case "b" -> changeLocation();
            default -> {
                System.out.println("Ungültige Eingabe. Bitte a oder b eingeben und mit Enter bestätigen.");
                this.whatToDo();
            }
        }

    }

    public void changeLocation() {
        System.out.println("Wohin willst du?");
        char at = 97;
        int[] index = new int[4];
        int j=0;

        for (int i = 0; i < TextAdventureB.raeume.length; i++) {
            if (TextAdventureB.standort.equals(TextAdventureB.raeume[i])) continue;
            index[j] = i;
            System.out.println(at + ") " + TextAdventureB.raeume[i].getName());
            at++;
            j++;
        }
        switch (getUserInput()) {
            case "a" -> TextAdventureB.standort = TextAdventureB.raeume[index[0]];
            case "b" -> TextAdventureB.standort = TextAdventureB.raeume[index[1]];
            case "c" -> TextAdventureB.standort = TextAdventureB.raeume[index[2]];
            case "d" -> TextAdventureB.standort = TextAdventureB.raeume[index[3]];
            default -> {
                System.out.println("Bitte nur Buchstabe a,b,c oder d eingeben und Enter drücken.");
                changeLocation();
            }
        }
        TextAdventureB.standort.onEntry();
    }
}
