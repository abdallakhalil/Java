package Tut06;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class RegisterMachine {
    static String[][] code;
    static int[] c;
    static int b;                               //Befehlszähler
    public static void main(String[] args) {
        //Initialisieren der Variablen
        code = programmEinlesen(args[0]);
        c = new int[1000];                      //Register
        int i;                                  //Argument
        try {
            b = Integer.parseInt(args[1]);
        }
        catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            System.err.println("Der befehlszähler ist keine natuerliche Zahl oder wurde nicht angegeben");
            System.exit(-1);
        }
        //Laden der Register
        if (args.length > 2) {
            for (int j = 0; j < (args.length-2); j++) {
                c[j] = Integer.parseInt(args[j+2]);
            }
        }
        //Ausführen des Programmes
        while (true){
            //Für Zeile b gilt code[b-1], da die erste Zeile code[0] ist
            i = Integer.parseInt(code[b-1][1]);
            switch (code[b-1][0]) {
                case "LOAD":
                    b++;
                    c[0] = c[i];
                    break;
                case "CLOAD":
                    b++;
                    c[0] = i;
                    break;
                case "STORE":
                    b++;
                    c[i] = c[0];
                    break;
                case "ADD":
                    b++;
                    c[0] += c[i];
                    break;
                case "CADD":
                    b++;
                    c[0] += i;
                    break;
                case "SUB":
                    b++;
                    c[0] = Math.max(0, (c[0] - c[i]));
                    break;
                case "CSUB":
                    b++;
                    c[0] = Math.max(0, (c[0] - i));
                    break;
                case "MULT":
                    b++;
                    c[0] *= c[i];
                    break;
                case "CMULT":
                    b++;
                    c[0] *= i;
                    break;
                case "DIV":
                    b++;
                    c[0] = c[0]/c[i];                   //"Abschneiden" des Restes geschieht implizit
                    break;
                case "CDIV":
                    b++;
                    c[0] = c[0]/i;
                    break;
                case "GOTO":
                    b = i;
                    break;
                case "IFZ":
                    if (c[0] == 0) b = i;
                    else b++;
                    break;
                case "IFNZ":
                    if (c[0] != 0) b = i;
                    else b++;
                    break;
                case "END":
                    System.exit(0);
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * Liest die Datei definiert in dateiname ein, speichert Befehle und Argumente getrennt im n*2 Array vom Typ String
     * und gibt dieses zurück
     * @param dateiname datei, die gelesen werden soll
     * @return int[][] code mit Befehlen in int[n][0] und Werten in int[n][1]
     */
    public static String[][] programmEinlesen (String dateiname) {
        try {
            File datei = new File(dateiname);   //todo: Speicherpfad richtig angeben
            FileReader fr = new FileReader(datei);
            BufferedReader br = new BufferedReader(fr);
            ArrayList<String> befehlL = new ArrayList<>();
            ArrayList<String> argument = new ArrayList<>();

            //Einlesen der Textdatei in befehlL und argument
            String eingabe = br.readLine();
            int i = 0;
            do {
                while (eingabe.charAt(i) != ' ') {
                    i++;
                }
                befehlL.add(eingabe.substring(0, i));    //2. Argument von Substring ist exklusiv
                argument.add(eingabe.substring(i+1));
                eingabe = br.readLine();
                i = 0;
            } while (eingabe != null && !eingabe.equals("END"));
            befehlL.add("END");

            //Zusammensetzten in code
            String[][] code = new String[befehlL.size()][2];
            for (int j = 0; j < argument.size(); j++) {
                code[j][0] = befehlL.get(j);
                code[j][1] = argument.get(j);
            }
            //Letzte Zeile muss manuelle gesetzt werden, da END kein Argument zugewiesen ist
            code[befehlL.size() - 1][0] = befehlL.get(befehlL.size() - 1);
            code[befehlL.size() - 1][1] = "0";

            //Überprüfen auf ungültige Werte
            try {
                String[] befehlssatz = {"LOAD", "CLOAD", "STORE", "ADD", "CADD", "SUB", "CSUB", "MULT", "CMULT", "DIV",
                        "CDIV", "GOTO", "IFZ", "IFNZ", "END"};
                for (int j = 0; j < argument.size(); j++) {
                    //ungültig, wenn Befehl nicht im Befehlssatz enthalten ist
                    boolean zeileGueltig = false;
                    for (String element : befehlssatz) {
                        if (code[j][0].equals(element)) {
                            zeileGueltig = true;
                            break;
                        }
                    }
                    //ungültig, wenn Argument<1, bei manchen Befehlen <0
                    if (Integer.parseInt(code[j][1]) < 1 && (!((code[j][0].equals("CLOAD") | code[j][0].equals("CADD") |
                            code[j][0].equals("MULT")) && Integer.parseInt(code[j][1]) < 0))) {
                        zeileGueltig = false;
                    }
                    if (!zeileGueltig) {
                        System.err.println("Befehl ist nicht im Befehlssatz enthalten");
                        System.exit(-1);
                    }
                }
            } catch (NumberFormatException e) {
                System.err.println("Argument des Befehls ist keine natuerliche Zahl");
                System.exit(-1);
            }

            return code;

        } catch (IOException e) {
            System.err.println("Datei konnte nicht gefunden werden");
            System.exit(1);                         //Fehler, der bekannter Weise auftreten kann
        }
        return (new String[][]{});
    }

}
