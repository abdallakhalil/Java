package Tut06;

/** Diese Klasse ist die Kommandobrücke. Hier startet man das Spiel.
 * Außerdem ist hier der Code zur Waffenkammer versteckt.
 */
public class FirstRoom extends Room{

    //Konstruktor führt zur Mutterklasse (Room)
    public FirstRoom(String name) {
        super(name);
    }

    // Beschreibung des Raums.
    public void getDescription(){
        System.out.println("Du befindest dich auf der Kommandobrücke. Viele Lämpchen und Knöpfe, viel hochkomplizierte" +
                "Technik und flimmernde Bildschirme.\nZum Glück wird der Großteil der Steuerung von KI übernommen, " +
                "sodass du nur im Notfall selber übernehmen musst.");
    }

    public void searchFor(){
        if (TextAdventureB.waffenkammer.firstTry){
            super.searchFor();
        }
        else {
            System.out.println("Auf dem Dashboard findest du dein Notizheft. Dir fällt ein, dass du darin den\n" +
                    "Zugangscode für die Waffenkammer gespeichert hast. Allerdings nicht in Form eines Rätsels." +
                    "\nDa steht:");
            System.out.println("Es sind fünf Ziffern gesucht. Die erste ist die Eins.\nDie zweite ist die erste Ziffer " +
                    "der Postleitzahl der OVGU.\nDie letzte ist die vierte Primzahl.\nDie vierte Ziffer ist die größte." +
                    "\nDie dritte Ziffer ist gleich einer der anderen." +
                    "\nSie ergibt mit der fünften Ziffer addiert die vierte Ziffer.\nNa, hast du es raus?");
            pressEnter();
            whatToDo();
        }
    }



}
