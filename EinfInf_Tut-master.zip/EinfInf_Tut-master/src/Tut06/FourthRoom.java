package Tut06;

import java.util.Scanner;

/** Diese Klasse ist die Waffenkammer. Um einzutreten ist die Eingabe eines Codes erforderlich.
 * Nachdem man diesen eingegeben hat kann man eine Waffe finden.
 */
public class FourthRoom extends Room {

    private boolean locked = true;
    public boolean firstTry = true;

    //Konstruktor führt zur Mutterklasse (Room)
    public FourthRoom(String name) {
        super(name);
    }

    public static String inputCode(){
        Scanner scan = new Scanner(System.in);
        return scan.nextLine();
    }

    @Override
    public void onEntry(){
        if (locked && firstTry){
            System.out.println("Du versuchst die Tür zur Waffenkammer zu öffnen, aber das Öffnen der Tür erfordert die " +
                    "Eingabe\neines fünfstelligen Codes. Den hast du vergessen... Irgendwo hast du ihn notiert.");
            firstTry = false;
            changeLocation();
        }
        else if (locked){
            System.out.println("Die Tür erfordert einen Code. Weißt du ihn? Dann gib ihn ein:");
            if (inputCode().equals("13187")){
                System.out.println("Glückwunsch! Der Code war richtig. Du trittst ein.");
                locked = false;
                onEntry();
            }
            else {
                System.out.println("Das Eingabefeld blinkt rot. Das war wohl eine falsche Eingabe.");
                changeLocation();
            }
        }
        else {
            System.out.println("Neuer Standort: " + getName());
            whatToDo();
        }
    }

    public void getDescription(){
        System.out.println("Du bist jetzt in der Waffenkammer. Da du dich auf Forschungsmission befindest," +
                "\nist diese allerdings nicht besonders gut bestückt.");
    }

    public void searchFor(){
        if (!TextAdventureB.hasGun){
          System.out.println("Im hintersten Waffenschränkchen wirst du fündig." +
                  "\nEine stattliche Laser-Wumme. Du nimmst sie vorsichtshalber mit.");
          TextAdventureB.hasGun = true;
          pressEnter();
          whatToDo();
        }
        else super.searchFor();
    }

}
