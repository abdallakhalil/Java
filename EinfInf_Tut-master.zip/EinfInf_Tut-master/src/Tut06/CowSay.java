package Tut06;

import java.util.Arrays;
// todo: Das Programm wurde nie fertiggestellt
public class CowSay {

    public static void textBoxAusgeben(String[] eingabeArray, int breite) {

        for (int i = 0; i < breite; i++) {
            System.out.print("_");
        }
        System.out.println("");
        zeileAusgeben(eingabeArray, 0, breite);

        System.out.println("");

        for (int i = 0; i < breite; i++) {
            System.out.print("-");
        }
    }

    /**
     * Rekursive Funktion zum ausgeben der Zeilen.
     * @param eingabeArray   Eingabewörter als Array (schon normalisiert)
     * @param index Ein Index für eingabeArray, der beim Funktionsaufruf mit übergeben wird.
     * @param breite    Maximallänge einer Zeile
     * @return  Gibt sich selber zurück
     */
    public static String zeileAusgeben(String[] eingabeArray, int index, int breite) {
        int restbreite = breite;

        String wort = "";
        int wortLaenge = 0;

        while (index < eingabeArray.length) {

            wort = eingabeArray[index];
            wortLaenge = eingabeArray[index].length();
            restbreite -= wortLaenge;

            if (restbreite >= 1) {
                System.out.print(wort + " ");
                restbreite --;
            }
            else if (restbreite == 0) {
                System.out.println(wort);
                return zeileAusgeben(eingabeArray, index + 1, breite);
            }
            else {
                System.out.println("");
                return zeileAusgeben(eingabeArray, index, breite);
            }

            index++;
        }

        return "";
    }

    /**
     * Gibt die Kuh (ein Array) aus. Die Kuh wird pro Zeile zusammengesetzt.
     * @param augen String, der die Augen representiert.
     * @param mitZunge  Wenn true, wird eine Zunge ausgegeben.
     */
    public static void kuhAusgeben(String augen, boolean mitZunge) {
        String zunge = " ";

        if (mitZunge) {
            zunge = "U";
        }

        String[] kuhArray = new String[5];

        kuhArray[0] = "         \\   ^__^";
        kuhArray[1] = "          \\  (" + augen + ")\\_______";
        kuhArray[2] = "             (__)\\       )\\/*";
        kuhArray[3] = "              " + zunge + "  ||----W |";
        kuhArray[4] = "                 ||     ||";

        for (int i = 0; i < kuhArray.length; i++) {
            System.out.println(kuhArray[i]);
        }
    }

    /**
     * Durchläuft dein Array und teilt einen zu breiten Parameter in zwei.
     * @param eingabeArray  Array, das auf Länge der einzelnen Parameter überprüft wird.
     * @param breite    Hier die Maximallänge, die ein Parameters am Ende haben soll
     * @return  "normalisierte" Variante von eingabeArray
     */
    public static String[] eingabeNormalisieren(String[] eingabeArray, int breite) {

        for (int i = 0; i < eingabeArray.length; i++) {

            if (eingabeArray[i].length() > breite) {

                String tempEingabe = eingabeArray[i];
                eingabeArray = Arrays.copyOf(eingabeArray, eingabeArray.length + 1);

                for (int j = i+1; j < eingabeArray.length-3; j+=3) {

                    String tempString = eingabeArray[j+1];
                    eingabeArray[j+1] = eingabeArray[j];
                    eingabeArray[j+2] = tempString;

                }
                eingabeArray[i] = tempEingabe.substring(0, breite);
                eingabeArray[i+1] = tempEingabe.substring(breite);
            }
        }

        return eingabeArray;
    }

    public static void main(String[] args) {

        String augen = "oo";
        String eingabeString = null;
        int breite = 40;
        boolean mitZunge = false;
        boolean zungeReversed = false;


        for (int i = 0; i < args.length; i++) {

            switch (args[i]) {
                case "-W":
                    breite = Integer.parseInt(args[i+1]);
                    break;
                case "-T":
                    zungeReversed = true;
                    break;
                case "-e":
                    augen = args[i+1];
                    break;
                case "-b":
                    augen = "==";
                    break;
                case "-d":
                    augen = "XX";
                    mitZunge = true;
                    break;
                case "-g":
                    augen = "$$";
                    break;
                case "-p":
                    augen = "@@";
                    break;
                case "-s":
                    augen = "**";
                    mitZunge = true;
                    break;
                case "-t":
                    augen = "--";
                    break;
                case "-w":
                    augen = "OO";
                    break;
                case "-y":
                    augen = "..";
                    break;
                default:
                    break;
            }
        }

        //EingabeString ist immer der letzte Parameter
        eingabeString = args[args.length - 1];


        if (mitZunge == zungeReversed) {
            mitZunge = false;
        }

        //Aus dem EingabeString wird ein Array (Trennung bei Leerzeichen
        String[] eingabeArray = eingabeString.split(" ");

        eingabeArray = eingabeNormalisieren(eingabeArray, breite);


        // Zeilen und Kuh ausgeben
        //zeileAusgeben(eingabeArray, 0, breite);
        textBoxAusgeben(eingabeArray, breite);

        System.out.println("");
        kuhAusgeben(augen, mitZunge);


    }
}