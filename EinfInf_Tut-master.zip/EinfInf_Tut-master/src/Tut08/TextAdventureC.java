package Tut08;

import java.util.Scanner;

public class TextAdventureC {

    //Alle benötigten Instanzen werden erzeugt.
    public static Player player = new Player();
    public static RandomMonster randomOpp = new RandomMonster();
    public static BossMonsterA firstBoss = new BossMonsterA("Zacharias Zorn", 4, 120, 110, 100, 200, 2000);
    public static BossMonsterA secondBoss = new BossMonsterA("Dörte die Gestörte", 6, 130, 100, 125, 250, 2400);
    public static BossMonsterA thirdBoss = new BossMonsterA("Zacharias Zorn", 8, 140, 118, 108, 300, 2600);
    public static BossMonsterA endBoss = new BossMonsterA("Endboss Erich", 10, 150, 120, 120, 400, 3000);
    public static BossMonsterB endBossB = new BossMonsterB("Bewaffneter Endboss Erich", 10, 150, 120, 120, true);
    public static Room1 flurEg = new Room1("Flur EG");
    public static Room2 healingRoom = new Room2("Heilungsraum");
    public static Room3 shop = new Room3("Shop");
    public static Room4 training = new Room4("Trainingsraum");
    public static Room5 flurOg = new Room5("Flur OG");
    public static Room6 firstBossRoom = new Room6("Erster Bossraum");
    public static Room7 secondBossRoom = new Room7("Zweiter Bossraum");
    public static Room8 thirdBossRoom = new Room8("Dritter Bossraum");
    public static Room9 endBossRoom = new Room9("Endgegnerraum");
    public static Room10 riddle = new Room10("Rätselraum");
    // standort kann jede Room Instanz annehmen und zeigt immer auf den Raum in dem man sich befindet.
    public static Room standort = flurEg;
    // Array zum erleichterten Wechseln des Raums
    public static Room[] rooms = {flurEg, healingRoom, shop, training, flurOg, firstBossRoom, secondBossRoom,thirdBossRoom,endBossRoom,riddle};


    //Methode für den Scanner
    public static String getUserInput(){
        Scanner scan = new Scanner(System.in);
        return scan.nextLine();
    }

    // Methode wartet auf Eingabe vom Spieler. Genutzt um das Spiel übersichtlichler zu halten
    public static void pressEnter(){
        System.out.println("Enter drücken, um fortzufahren.");
        getUserInput();
    }

    // Methode nimmt Werte von chooseFighter() und speichert diese in den Stats von player
    public static void setPlayerStats(String name, int level, int hp, int atk, int def){
        player.setName(name);
        player.setLevel(level);
        player.setHp(hp);
        player.setCurrentHp(hp);
        player.setAtk(atk);
        player.setDef(def);
    }

    // Je nach Auswahl erhält player unterschiedliche Werte
    public static void chooseFighter(){
        System.out.println("a) Achim der Ausgeglichene\nb) Doris die Defensive\nc) Otto der Offensive");

        switch (getUserInput()){
            case "a" -> setPlayerStats("Achim der Ausgeglichene", 1, 100, 115, 115);
            case "b" -> setPlayerStats("Doris die Defensive", 1, 100, 100, 130);
            case "c" -> setPlayerStats("Otto der Offensive", 1, 100, 130, 100);
            default -> {
                System.out.println("Fehlerhafte Eingabe! Erneut versuchen:");
                chooseFighter();
            }
        }

    }

    //Wird aufgerufen, wenn endboss (bzw. endbossB) besiegt wurde und der Spieler das Spiel damit gewinnt
    public static void gameWon() {
        System.out.println("Herzlichen Glückwunsch! Du hast den Endboss bezwungen. Spiel abgeschlossen.");
        System.exit(1);
    }

    public static void main(String[] args) {

        //Auswahl des gewünschten Charakters
        System.out.println("Willkommen im Dojo. Bevor es losgeht, wähle deinen Charakter:");
        chooseFighter();

        //Kurze Einleitung ins Spiel
        System.out.println("Gewählter Charakter: " + player.getName());
        System.out.println("""
                Dein Abenteuer beginnt. Du bist ein Kämpfer und hast das Ziel, die Gegner im oberen Stockwerk zu besiegen.
                Doch bevor du das tust, sieh dich ruhig um und erkunde die Arena ein wenig!
                
                """);
        pressEnter();

        //Springt in die whatdo() Methode vom Flur EG
        standort.whatdo();


    }


}
