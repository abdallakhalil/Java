package Tut08;

public abstract class PlayerEntity {

    // Maximale Gesundheit der Entity
    private int hp;
    // Momentane Gesundheit der Entity
    private int currentHp;
    private String name;
    private int level;
    private int atk;
    private int def;
    //gibt an, ob Spieler eine Waffe hat
    private boolean hasGun = false;

    // gibt "|" * currentHp aus und ggf. auch noch "." * hp (wenn currentHp != hp)
    public void showHp(){
        for (int i = 1; i <= hp; i++) {
            if (i <= currentHp){
                System.out.print("|");
            }
            else System.out.print(".");
        }
        System.out.print("\n\n");
    }

    //Jeder Angriff hat eine Chance von 30% den Schaden auf das 1.5-fache zu erhöhen
    private double critFactor(){
        double f = Math.random();
        if (f < 0.3){
            return 1.5;
        }
        else {
            return 1;
        }
    }

    // gibt den Grundschaden des Angriffs zurück. Normalerweise 30, außer beide Spieler haben eine Waffe
    private int damagefactor(PlayerEntity attacker, PlayerEntity defender){
        if (attacker.getHasGun() & defender.getHasGun()){
            return 60;
        }
        else return 30;
    }

    //Berechnet den verursachten Schaden. Vorbild war die Schadensberechnung bei Pokemon
    public int damageCalc(PlayerEntity attacker, PlayerEntity defender){
        double damage = damagefactor(attacker, defender) * (attacker.getAtk()/ (defender.getDef()*1.0) * critFactor() * (1 + attacker.getLevel()/100.0));
        return (int) damage;
    }

    //Ab hier nur getter & setter
    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public int getLevel(){
        return level;
    }

    public void setLevel(int level){
        this.level = level;
    }

    public int getHp(){
        return hp;
    }

    public void setHp(int hp){
        this.hp = hp;
    }

    public int getCurrentHp(){
        return currentHp;
    }

    public void setCurrentHp(int hp){
        this.currentHp = hp;
    }

    public int getAtk() {
        return atk;
    }

    public void setAtk(int atk) {
        this.atk = atk;
    }

    public int getDef() {
        return def;
    }

    public void setDef(int def) {
        this.def = def;
    }

    public boolean getHasGun() {
        return hasGun;
    }

    public void setHasGun(boolean hasGun) {
        this.hasGun = hasGun;
    }







}

