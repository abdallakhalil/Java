package Tut08;

/**
 * Klasse für Instanz player, also den vom User gesteuerten Spieler.
 * Hier ist die Kampfsequenz gegen andere PlayerEntities implementiert.
 * Außerdem kann Player im Vergleich zu PlayerEntity Tränke benutzen und kann sein Level durch Sammeln von Erfahrung erhöhen.
 */
public class Player extends PlayerEntity {
    //momentane Erfahrungspunkte (EXP)
    private int exp = 0;
    //EXP zum nächsten Level
    private int expToNextLv = 200;
    //zur Verfügung stehender Geldbetrag
    private int money = 1000;
    //zur Verfügung stehende Tränke
    private int potions = 5;
    //gibt an, welche Bosse schon besiegt wurden
    private boolean boss1Defeated = false;
    private boolean boss2Defeated = false;
    private boolean boss3Defeated = false;

    //Konstruktor
    public Player(){

    }

    //implementiert das Aufladen der HP durch Tränke
    public void usePotion(){

        //Hat man keine Tränke mehr, kann man auch keinen trinken.
        if (this.potions == 0){
            System.out.println("Du hast keine Tränke mehr!");
        }
        //Hat man noch Tränke erhöht sich die HP um höchstens 50, die Anzahl Tränke verringert sich um 1
        else {
            System.out.println("Trank wurde eingesetzt!");
            setCurrentHp(Math.min(getCurrentHp() + 50, getHp()));
            this.potions -= 1;
        }
    }

    //Wird von der fight Methode aufgerufen, solang kein Spieler besiegt ist.
    private void fightRound(PlayerEntity enemy){

        //Zeigt die Gesundheit vom Gegner und vom Spieler an.
        //Erklärung showHp Methode siehe PlayerEntity.showHp()
        System.out.println(enemy.getName() + "s Gesundheit: " + enemy.getCurrentHp() + "/" + enemy.getHp());
        enemy.showHp();
        System.out.println("Deine Gesundheit: " + this.getCurrentHp() + "/" + this.getHp());
        this.showHp();

        //Standard Auswahl mit switch case
        System.out.println("Was möchtest du tun?");
        System.out.println("a) Angreifen\nb) Trank einnehmen & dann angreifen (Tränke im Gepäck: " + getPotions() + ")");
        switch (TextAdventureC.getUserInput()){
            case "a" -> {

                //Schaden entspricht damageCalc (siehe PlayerEntity.damageCalc())
                int damage = damageCalc(this, enemy);
                //Schaden wird von gegnerischen HP abgezogen
                enemy.setCurrentHp(enemy.getCurrentHp() - damage);
                System.out.println("Ausgeteilter Schaden: " + damage);
                TextAdventureC.pressEnter();
            }

            //gleiches vorgehen wie bei case a, nur wird vorher ein Trank eingesetzt
            case "b" -> {
                usePotion();
                int damage = damageCalc(this, enemy);
                enemy.setCurrentHp(enemy.getCurrentHp() - damage);
                System.out.println("Ausgeteilter Schaden: " + damage);
                TextAdventureC.pressEnter();
            }
            default -> {
                System.out.println("Ungültige Eingabe!");
                fightRound(enemy);
            }
        }

        //Sollte der Gegner noch leben, greift er zurück an. Schadensberechnung analog zu oben
        if (enemy.getCurrentHp() > 0){
            System.out.println(enemy.getName() + " greift dich an!");
            this.setCurrentHp(getCurrentHp() - damageCalc(enemy, this));
            System.out.println("Du hast Schaden erhalten!");
            TextAdventureC.pressEnter();
        }
    }

    //Methode wird zu Beginn eines Kampfes aufgerufen.
    public void fight(BossMonsterA enemy){

        //Option wird angezeigt wenn man die Waffe gefunden und gegen den Endboss kämpfen will.
        if (TextAdventureC.player.getHasGun() && enemy.equals(TextAdventureC.endBoss)){
            System.out.println("""
                    Du hast eine Knarre. Als wahrer Gentleman würdest du sie nie gegen Unbewaffnete einsetzen,
                    aber der Endboss hat ebenfalls eine, ihr könntet also euch auch gegenseitig wegballern.
                    Das verdoppelt den Schaden. Willst du das?
                    a) Ja
                    b) Lieber eine old-fashioned Schlägerei
                    """);
            switch(TextAdventureC.getUserInput()){
                case "a" -> fight(TextAdventureC.endBossB);
                case "b" -> {
                    System.out.println("Alles klar, los gehts.");
                    TextAdventureC.pressEnter();
                }
                default -> {
                    System.out.println("Falsche Eingabe!");
                    fight(enemy);
                }
            }
        }

        // Wird nur zu Beginn des Kampfes angezeigt.
        System.out.println("Ein neuer Herausforderer: " + enemy.getName() + " Level: " + enemy.getLevel());

        //Kampf läuft solang kein Spieler besiegt ist.
        while (getCurrentHp() > 0 && enemy.getCurrentHp() > 0) {
            fightRound(enemy);
        }

        // Hat der Spieler am Ende der while schleife noch mehr als 0 HP heißt das er hat den Kampf gewonnen.
        if (this.getCurrentHp() > 0){

            // Es werden die vom Gegner bereitgestellten EXP und Geld gutgeschrieben
            System.out.println(enemy.getName() + " wurde besiegt.\n\n" +
                    "Du hast gewonnen!\nErhaltene Erfahrungspunkte: " + enemy.getGiveExp() +
                    "\nErhaltenes Geld: " + enemy.getGiveMoney());
            setMoney(getMoney() + enemy.getGiveMoney());
            setExp(getExp() + enemy.getGiveExp());

            // Füllt Gesundheit des Gegners wieder auf, für den Fall dass man ihn nochmal bekämpft
            enemy.setCurrentHp(enemy.getHp());
            TextAdventureC.pressEnter();

            //Für den Fall, dass man so viel EXP bekommt, wie für zwei level ups reichen, wird die methode doppelt aufgerufen.
            checkForLevelUp();
            checkForLevelUp();

            //War der Gegner der Endboss, hat man das Spiel durch den Sieg gegen ihn gewonnen
            if(enemy.equals(TextAdventureC.endBoss) || enemy.equals(TextAdventureC.endBossB)){
                TextAdventureC.gameWon();
            }

            // Nach Kämpfen gegen die Bosse landet man im oberen flur
            if (!enemy.equals(TextAdventureC.randomOpp)){
                TextAdventureC.standort = TextAdventureC.flurOg;
            }
            TextAdventureC.standort.whatdo();

        }

        //Ist man nicht der überlebende Spieler, verliert man und das Programm bricht ab.
        else {
            System.out.println("Du hast verloren. Rest in Peace ;(");
            System.exit(-1);
        }
    }

    // Verändert die stats des Spielers bei level up
    private void levelUp(){
        this.setHp(getHp() + 2);
        this.setLevel(getLevel() + 1);
        this.setAtk(getAtk() + 2);
        this.setDef(getDef() + 2);
    }

    // Prüft, ob ein level up verfügbar ist.
    public void checkForLevelUp(){

        //Level up nur bis Level 100
        if (exp >= expToNextLv && getLevel() < 100){
            levelUp();
            System.out.println("Neues Level erreicht! Du bist jetzt Level " + getLevel());
            // setzt exp zurück
            exp -= expToNextLv;

            //Die benötigte XP zum nächsten Level erhöht sich um (etwa) 10%
            expToNextLv += expToNextLv/10;
            System.out.println("Erfahrung bis zum nächsten Level: " + (expToNextLv - exp));
            TextAdventureC.pressEnter();
        }
    }

    //Ab hier nur getter & setter
    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public int getExp(){
        return exp;
    }

    public void setExp(int exp){
        this.exp = exp;
    }

    public int getPotions() {
        return potions;
    }

    public void setPotions(int potions) {
        this.potions = potions;
    }

    public boolean isBoss1Defeated() {
        return boss1Defeated;
    }

    public void setBoss1Defeated(boolean boss1Defeated) {
        this.boss1Defeated = boss1Defeated;
    }

    public boolean isBoss2Defeated() {
        return boss2Defeated;
    }

    public void setBoss2Defeated(boolean boss2Defeated) {
        this.boss2Defeated = boss2Defeated;
    }

    public boolean isBoss3Defeated() {
        return boss3Defeated;
    }

    public void setBoss3Defeated(boolean boss3Defeated) {
        this.boss3Defeated = boss3Defeated;
    }
}
