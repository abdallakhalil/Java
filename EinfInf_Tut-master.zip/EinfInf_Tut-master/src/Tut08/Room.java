package Tut08;

import java.util.Scanner;

/**
 * Die Mutterklasse aller anderen Räume. Hier findet vor allem der Wechsel zwischen den Räumen statt.
 */
public abstract class Room {

    //Name soll nicht geändert werden, daher final
    private final String name;

    public Room (String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }

    //Gibt die Beschreibung eines Raums. Ist abstrakt, da die Beschreibung je nach Room variiert.
    public abstract void getDescription();

    //Methode um User Input zu bekommen
    public String getUserInput(){
        Scanner scan = new Scanner(System.in);
        return scan.nextLine();
    }

    //Wird von den Tochterklassen aufgerufen wenn man sie "betritt"
    public  abstract void whatdo();

    //Ändert den Standort des Spielers zu Raum an stelle i im Room Array
    public void changeRoom(int i){
        TextAdventureC.standort = TextAdventureC.rooms[i];
        TextAdventureC.standort.whatdo();
    }
}


