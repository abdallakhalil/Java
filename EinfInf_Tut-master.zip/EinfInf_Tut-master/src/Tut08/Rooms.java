package Tut08;

/**
 * Jeder Raum hat seine eigene Klasse
 */
public class Rooms {}

/**
 * Klasse für den FLur im EG.
 * Von hier erfolgt der Wechsel zu Room2, Room3, Room4, Room5
 */
class Room1 extends Room{

    public Room1(String name) {
        super(name);
    }

    public void getDescription(){
        System.out.println("Du bist im unteren FLur. Von hier kommst du in die anderen Räume oder ins Obergeschoss.");
    }

    //Methode zum Raumwechsel mit Standard switch case
    @Override
    public void whatdo(){
        getDescription();
        System.out.println("""
                Wohin willst du?
                a) Heilungsraum
                b) Shop
                c) Trainingsraum
                d) nach oben""");


        switch (getUserInput()){
            case "a" -> changeRoom(1);
            case "b" -> changeRoom(2);
            case "c" -> changeRoom(3);
            case "d" -> changeRoom(4);
            default -> {
                System.out.println("Fehlerhafte Eingabe!");
                whatdo();
            }
        }
    }
}

/**
 * Klasse für den Heilungsraum. Hier kann man seine Gesundheit gratis auffüllen
 */
class Room2 extends Room{

    public Room2(String name) {
        super(name);
    }

    // Zeigt Handlungsoptionen und aktuelle Gesundheit an
    public void getDescription(){
        System.out.println("Du bist im Heilungsraum.");
        System.out.println("Deine Gesundheit: ");
        TextAdventureC.player.showHp();
        System.out.println("Willst du dich heilen?\na) Ja\nb) Zurück in den Flur");
    }

    @Override
    public void whatdo() {
        getDescription();
        switch(getUserInput()){
            case "a" -> heal();
            case "b" -> changeRoom(0);
            default -> {
                System.out.println("Ungültige Eingabe!");
                whatdo();
            }
        }
    }

    // Setzt currentHp auf den Wert von hp
    private void heal() {
        System.out.println("Volle Gesundheit wieder hergestellt.");
        TextAdventureC.player.setCurrentHp(TextAdventureC.player.getHp());
        whatdo();
    }
}

/**
 * Klasse für den Shop. Hier kann man Tränke für 200 Geld kaufen
 */
class Room3 extends Room{

    public Room3(String name){
        super(name);
    }

    public void getDescription(){
        System.out.println("Du bist im Shop. Hier kannst du Tränke kaufen. Diese erhöhen deine Gesundheit um 50.");
    }

    @Override
    public void whatdo() {
        getDescription();
        System.out.println("""
                Was willst du tun?
                a) Tränke kaufen
                b) zurück""");

        switch(getUserInput()){
            case "a" -> buy();
            case "b" -> changeRoom(0);
            default -> {
                System.out.println("Ungültige Eingabe!");
                whatdo();
            }
        }
    }

    // Methode zur Transaktion von Tränken gegen Geld
    public void buy(){

        System.out.println("Dein Guthaben: " + TextAdventureC.player.getMoney() + "$");
        System.out.println("Tränke im Gepäck: " + TextAdventureC.player.getPotions());
        System.out.println("Ein Trank kostet 200$. Wieviele Tränke willst du kaufen?");

        // Try Catch aus dem UserInput ein int zu machen.
        int i = 0;
        try{
            i = Integer.parseInt(getUserInput());
        }catch(Exception e){
            System.out.println("Ungültige Eingabe!");
            buy();
        }


        // Falls der Spieler mehr Tränke kaufen will als er kann
        if (i * 200 > TextAdventureC.player.getMoney()){
            System.out.println("Das kannst du dir nicht leisten! Du hast Geld für " +
                    TextAdventureC.player.getMoney() / 200 + " Tränke.");
        }
        // Falls er mehr als 0 Tränke kaufen will.
        else if (i > 0){
            System.out.println("Vielen Dank für den Einkauf!");
            TextAdventureC.player.setMoney(TextAdventureC.player.getMoney() - (i * 200));
            TextAdventureC.player.setPotions(TextAdventureC.player.getPotions() + i);
        }
        // Falls i <= 0
        else System.out.println("Ungültige Eingabe.");

        whatdo();

    }

}

/**
 * Klasse für den Trainingsraum. Hier kann man gegen RandomMonster kämpfen.
 */
class Room4 extends Room{
    public Room4(String name) {
        super(name);
    }

    public void getDescription(){
        System.out.println("""
                Hier kannst du trainieren. Willst du jetzt gegen einen zufälligen kämpfen?
                a) Ja
                b) Zurück in den Flur""");
    }

    @Override
    public void whatdo() {
        getDescription();
        switch(getUserInput()){
            case "a" -> {
                // Bei jedem Kampf werden zunächst die Stats von randomOpp angepasst
                TextAdventureC.randomOpp.randomOpponentStats();
                TextAdventureC.player.fight(TextAdventureC.randomOpp);
            }
            case "b" -> changeRoom(0);
            default -> {
                System.out.println("Ungültige Eingabe!");
                whatdo();
            }
        }
    }
}

/**
 *Klasse für den FLur im OG.
 * Von hier erfolgt der Wechsel zu Room0, Room6, Room7, Room8, Room9, Room10
 */
class Room5 extends Room{
    public Room5(String name) {
        super(name);
    }

    public void getDescription(){
        System.out.println("Du bist im Flur im Obergeschoss. Von hier gelangst du in weitere Räume oder nach unten.");
    }

    // Methode zum Raumwechsel mit Standard switch case
    @Override
    public void whatdo(){
        getDescription();
        System.out.println("""
                Wohin willst du?
                a) Erster Bossraum
                b) Zweiter Bossraum
                c) Dritter Bossraum
                d) Endgegnerraum
                e) Rätselraum
                f) nach unten""");

        switch (getUserInput()){
            case "a" -> changeRoom(5);
            case "b" -> changeRoom(6);
            case "c" -> changeRoom(7);
            case "d" -> changeRoom(8);
            case "e" -> changeRoom(9);
            case "f" -> changeRoom(0);
            default -> {
                System.out.println("Fehlerhafte Eingabe!");
                whatdo();
            }
        }
    }
}

/**
 * Klasse für den ersten Boss.
 */
class Room6 extends Room{

    public Room6(String name) {
        super(name);
    }

    public void getDescription(){
        System.out.println("""
                Der erste Boss wartet auf dich. Bist du bereit ihm entgegenzutreten?
                a) Ja
                b) Lieber zurück
                """);
    }

    @Override
    public void whatdo() {
        getDescription();
        switch(getUserInput()){
            case "a" -> {
                // Da das Spiel eh abbricht wenn man verliert, kann auch jetzt schon ein Sieg vermerkt werden
                TextAdventureC.player.setBoss1Defeated(true);
                TextAdventureC.player.fight(TextAdventureC.firstBoss);
            }
            case "b" -> changeRoom(4);
            default -> {
                System.out.println("Ungültige Eingabe!");
                whatdo();
            }
        }
    }

}

/**
 * Klasse für den zweiten Bossraum. Analog zu Room6, nur dass der zweite Boss erst bekämpft werden kann, wenn der erste
 * bereits besiegt wurde.
 */
class Room7 extends Room{
    public Room7(String name) {
        super(name);
    }

    public void getDescription(){
        System.out.println("""
                Der zweite Boss wartet auf dich. Bist du bereit ihm entgegenzutreten?
                a) Ja
                b) Lieber zurück
                """);

    }

    @Override
    public void whatdo() {
        getDescription();
        switch(getUserInput()){
            case "a" -> {
                if (TextAdventureC.player.isBoss1Defeated()) {
                    TextAdventureC.player.setBoss2Defeated(true);
                    TextAdventureC.player.fight(TextAdventureC.secondBoss);
                }
                else {
                    System.out.println("Du musst zuerst den ersten Boss besiegen!");
                    TextAdventureC.standort = TextAdventureC.flurOg;
                    TextAdventureC.standort.whatdo();
                }

            }
            case "b" -> changeRoom(4);
            default -> {
                System.out.println("Ungültige Eingabe!");
                whatdo();
            }
        }
    }
}

/**
 * Klasse für den dritten Bossraum. Analog zu Room7, nur dass man den zweiten Boss zuerst besiegt haben muss um zu kämpfen.
 */
class Room8 extends Room{

    public Room8(String name) {
        super(name);
    }

    public void getDescription(){
        System.out.println("""
                Der dritte Bboss wartet auf dich. Bist du bereit ihm entgegenzutreten?
                a) Ja
                b) Lieber zurück
                """);
    }

    @Override
    public void whatdo() {
        getDescription();
        switch(getUserInput()){
            case "a" ->  {
                if (TextAdventureC.player.isBoss2Defeated()){
                    TextAdventureC.player.setBoss3Defeated(true);
                    TextAdventureC.player.fight(TextAdventureC.thirdBoss);
                }
                else {
                    System.out.println("Du musst zuerst den zweiten Boss besiegen!");
                    TextAdventureC.standort = TextAdventureC.flurOg;
                    TextAdventureC.standort.whatdo();
                }

            }
            case "b" -> changeRoom(4);
            default -> {
                System.out.println("Ungültige Eingabe!");
                whatdo();
            }
        }
    }
}

/**
 * Klasse für den Raum mit Endboss. Man kann gegen ihn kämpfen wenn man den dritten Boss besiegt hat.
 * Das Spiel endet nach dem Kampf gegen ihn.
 */
class Room9 extends Room{
    public Room9(String name) {
        super(name);
    }

    public void getDescription(){
        System.out.println("""
                Der Endboss wartet auf dich. Bist du bereit ihm entgegenzutreten?
                a) Ja
                b) Lieber zurück
                """);
    }

    @Override
    public void whatdo() {
        getDescription();
        switch(getUserInput()){
            case "a" -> {
                if (TextAdventureC.player.isBoss3Defeated()) {
                    TextAdventureC.player.fight(TextAdventureC.endBoss);
                }
                else {
                    System.out.println("Du musst zuerst den dritten Boss besiegen!");
                    TextAdventureC.standort = TextAdventureC.flurOg;
                    TextAdventureC.standort.whatdo();
                }
            }

            case "b" -> changeRoom(4);
            default -> {
                System.out.println("Ungültige Eingabe!");
                whatdo();
            }
        }
    }
}

/**
 * Klasse für den Rätselraum. Hier kann der Spieler ein Rätsel lösen und als Belohnung eine Waffe erhalten.
 */
class Room10 extends Room{

    // Gibt an, ob das Rätsel gelöst wurde
    private boolean solved = false;

    public Room10(String name) {
        super(name);
    }

    // Hat man das Rätsel gelöst erhält man andere Beschreibung
    public void getDescription(){
        if (solved){
            System.out.println("Du bist im Rätselraum. Das Rätsel hast du bereits gelöst.");
        }
        else {
            System.out.println("Du bist im Rätselraum. Hier kannst du ein Rätsel lösen und dafür eine Belohnung erhalten.");
        }
    }

    // Gibt an, was man im Rätselraum tun kann.
    @Override
    public void whatdo() {
        getDescription();
        System.out.println("Was willst du tun?\na) Rätsel lösen\nb) zurück");
        switch(getUserInput()){
            case "a" -> checkIfRiddleIsSolved();
            case "b" -> changeRoom(4);
        }
    }

    // Methode wird zwischen whatdo() und solveRiddle geschaltet um zu prüfen ob das Rätsel bereits gelöst wurde
    private void checkIfRiddleIsSolved(){
        if (!solved){
            solveRiddle();
        }
        else {
            System.out.println("Du weißt ja die Lösung sowieso schon!");
            whatdo();
        }
    }

    // Methode gibt dem Spieler das Rätsel und lässt ihn Lösungsvorschläge eingeben
    private void solveRiddle() {

        System.out.println("""
                Hier das Rätsel:
                Gesucht ist eine vierstellige Zahl.
                Die erste Ziffer ist Prim.
                Die zweite Ziffer ist das doppelte der ersten Ziffer.
                Die dritte Ziffer ist das dreifache der ersten Ziffer.
                Die vierte Ziffer ist die dritte Ziffer halbiert plus 1.
                Wie lautet die Zahl?
                Kleiner Tipp: 100110110101
                
                Lösung hier eingeben und mit Enter bestätigen: 
                """);

        // Prüft, ob die Eingabe der Lösung (2485) entspricht und gibt dem Spieler je nachdem die Waffe
        if ("2485".equals(getUserInput())) {
            System.out.println("""
                Korrekt! Aus Anerkennung für deine Intelligenz hier ein Geschenk: Eine Knarre! 
                Wenn du gegen den Endboss antrittst, kannst du sie benutzen.
                """);
            TextAdventureC.player.setHasGun(true);
            solved = true;
        } else {
            System.out.println("Leider nicht...");
        }
        TextAdventureC.pressEnter();
        whatdo();
    }
}
