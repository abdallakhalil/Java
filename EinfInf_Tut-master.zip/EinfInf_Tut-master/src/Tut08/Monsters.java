package Tut08;

/**
 * Klassen für die verschiedenen im Spiel auffindbaren Gegner
 */
public class Monsters {
}

/**
 * Erweitert PlayerEntity um die Attribute giveExp und giveMoney, welche angeben, wieviel EXP und Geld man nach dem besiegen bekommt
 */
class BossMonsterA extends PlayerEntity {
    private int giveExp = 0;
    private int giveMoney = 0;

    public BossMonsterA(){
        super();
    }

    // Konstruktor
    public BossMonsterA(String name, int level, int hp, int atk, int def, int giveExp, int giveMoney){
        setName(name);
        setLevel(level);
        setHp(hp);
        setCurrentHp(hp);
        setAtk(atk);
        setDef(def);
        this.giveExp = giveExp;
        this.giveMoney = giveMoney;
    }


    // getter & setter
    public int getGiveExp() {
        return giveExp;
    }

    public int getGiveMoney() {
        return giveMoney;
    }

    public void setGiveExp(int giveExp){
        this.giveExp = giveExp;
    }

    public void setGiveMoney(int giveMoney){
        this.giveMoney = giveMoney;
    }
}

/**
 * Erweitert BossMonsterA um die Möglichkeit, die Attributwerte gemäß dem Spielerfortschritt zu ändern
 */
class RandomMonster extends BossMonsterA{

    String[] randomNames = {"Klaus Karpfenmaul", "Jens Jagdwurst", "Meike Monster", "Horst Hackfresse",
            "Nils Nektarine", "Gerda Gestank", "Wilfried Lichsein", "Angela Merkel"};


    // Diese Methode weist den Attributen einer Instanz von RandomMonster Werte in Abhängigkeit der Attributwerte von player zu
    // Die Werte Hp, Atk, Def entsprechen etwa 70% der Werte von player. Das Level entspricht dem von player
    // Daraus errechnet sich wieviel Geld und EXP man erhält
    // Der Name wird zufällig aus randomNames[] geholt.
    public void randomOpponentStats(){
        int i = (int) (Math.random()*8);
        setName(randomNames[i]);
        setHp((int) (TextAdventureC.player.getHp()/ 100.0)*70);
        setCurrentHp(getHp());
        setAtk((int) (TextAdventureC.player.getAtk()/ 100.0)*70);
        setDef((int) (TextAdventureC.player.getDef()/ 100.0)*70);
        setLevel(TextAdventureC.player.getLevel());
        setGiveExp((int) (getHp()*1.5));
        setGiveMoney((int) (getHp()*1.9));
    }
}

/**
 * Erweitert BossMonsterA eigentlich nur um einen speziellen Konstruktor
 */
class BossMonsterB extends BossMonsterA {

    public BossMonsterB(String name, int level, int hp, int atk, int def, boolean hasGun){
        this.setName(name);
        this.setLevel(level);
        this.setHp(hp);
        this.setCurrentHp(hp);
        this.setAtk(atk);
        this.setDef(def);
        this.setHasGun(hasGun);
    }

}
