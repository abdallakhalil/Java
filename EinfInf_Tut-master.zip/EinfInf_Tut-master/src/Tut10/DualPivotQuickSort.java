package Tut10;

import java.util.Arrays;

public class DualPivotQuickSort {

    public static void quickSort(int[] a) {
        _quicksort(a, 0, a.length-1);
    }

    public static void _quicksort(int[] a, int left, int right) {
        if (right > left) {
            int pivot = partition(a, left, right);
            _quicksort(a, left, pivot-1);
            _quicksort(a, pivot+1, right);
        }
    }

    public static int partition(int[] a, int left, int right) {
        assert (left <= right);

        int pivot = a[right];
        int temp = 0;
        int i = left - 1;
        int j = right;

        do {
            do ++i; while (a[i] < pivot);
            do --j; while (j > 1 && a[j] > pivot);

            temp = a[i];
            a[i] = a[j];
            a[j] = temp;

        } while (i < j);

        a[j] = a[i];
        a[i] = a[right];
        a[right] = temp;

        return i;

    }

    public static void dualPivotQuicksort(int[] a) {
        _dualPivotQuicksort(a, 0, a.length-1);
    }

    private static void _dualPivotQuicksort(int[] array, int l, int r) {
        if (r > l) {
            int[] pivot = partitionDualPivot(array, l, r);
            _dualPivotQuicksort(array, l, pivot[0]-1);
            _dualPivotQuicksort(array, pivot[0]+1, pivot[1]-1);
            _dualPivotQuicksort(array, pivot[1]+1, r);
        }
    }

    private static int[] partitionDualPivot(int[] array, int l, int r) {
        /*  todo: Der Partitionsalgorithmus funktioniert nicht zuverlässig! (Insbesondere bei längeren Arrays)
            möglicher Schwachpunkt sind die letzten beiden if Abfragen, da hier nicht immer des Pivotelement an die
            richtige Stelle geswapt wird. (Muss noch weiter untersucht werden)
         */

        assert (l <= r);

        int x = l+1;
        int y = r-1;
        int a = r-1;
        int b = l+1;
        boolean wurdeFuerP1Geswapt = false;
        boolean wurdeFuerP2Geswapt = false;
        int[] rueckgabe = {r, l};

        if (array[l] > array[r]) {
            swap(array, r, l);
        }

        while (x < y || a > b) {
            if (x < y) {
                if (array[x] > array[l] && array[y] < array[l]) {
                    swap(array, x, y);
                    x++;
                    y--;
                    wurdeFuerP1Geswapt = true;
                } else {
                    if (array[x] <= array[l]) x++;
                    if (array[y] >= array[l]) y--;
                }
            }

            if (a > b) {
                if (array[a] < array[r] && array[b] > array[r]) {
                    swap(array, a, b);
                    a--;
                    b++;
                    wurdeFuerP2Geswapt = true;
                } else {
                    if (array[a] >= array[r]) a--;
                    if (array[b] <= array[r]) b++;
                }
            }
        }
        if (wurdeFuerP1Geswapt) {
            swap(array, r, y);
            rueckgabe[0] = y;
        }
        if (wurdeFuerP2Geswapt) {
            swap(array, l, b);
            rueckgabe[1] = b;
        }
        return rueckgabe;
    }

    private static void swap (int[] array, int indexA, int indexB) {
        int tmp = array[indexA];
        array[indexA] = array[indexB];
        array[indexB] = tmp;
    }

    public static void main(String[] args) {

        int n = 10;
        int[] a = new int[n];

        for (int i = 0; i < n; i++) {
            a[i] = (int) (Math.random() * 100);
        }

        System.out.println(Arrays.toString(a));

        //quickSort(a);
        dualPivotQuicksort(a);

        System.out.println(Arrays.toString(a));
    }
}
