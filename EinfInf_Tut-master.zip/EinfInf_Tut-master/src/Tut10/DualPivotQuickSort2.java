package Tut10;

import java.util.Arrays;

public class DualPivotQuickSort2 {

    public static void quickSort(int[] a) {
        _quicksort(a, 0, a.length-1);
    }

    public static void _quicksort(int[] a, int left, int right) {
        if (right > left) {
            int pivot = partition(a, left, right);
            _quicksort(a, left, pivot-1);
            _quicksort(a, pivot+1, right);
        }
    }

    public static int partition(int[] a, int left, int right) {
        assert (left <= right);

        int pivot = a[right];
        int temp = 0;
        int i = left - 1;
        int j = right;

        do {
            do ++i; while (a[i] < pivot);
            do --j; while (j > 1 && a[j] > pivot);

            temp = a[i];
            a[i] = a[j];
            a[j] = temp;

        } while (i < j);

        a[j] = a[i];
        a[i] = a[right];
        a[right] = temp;

        return i;

    }

    public static void dualPivotQuicksort(int[] a) {
        _dualPivotQuicksort(a, 0, a.length-1);
    }

    private static void _dualPivotQuicksort(int[] array, int left, int right) {
        if (right >= left) {
            int[] pivot = partitionDualPivot(array, left, right);
            _dualPivotQuicksort(array, left, pivot[0]-1);
            _dualPivotQuicksort(array, pivot[0] + 1, pivot[1]-1);
            _dualPivotQuicksort(array, pivot[1] + 1, right);

        }
    }

    private static int[] partitionDualPivot(int[] a, int left, int right) {
        if (a[left] > a[right]){
            swap(a,left,right);
        }
        int i = left +1;
        int obergrenze = right -1;
        int untergrenze = left + 1;
        int lowPivot = a[left];
        int highPivot = a[right];
        int[] pivots = new int[2];

        while (obergrenze >= untergrenze)
        {

            // If elements are less than the left pivot
            if (a[untergrenze] < lowPivot)
            {
                swap(a, untergrenze, i);
                i++;
            }

            // If elements are greater than or equal
            // to the right pivot
            else if (a[untergrenze] >= highPivot){

                while (a[obergrenze] > highPivot && untergrenze < obergrenze){

                    obergrenze--;
                }

                swap(a, untergrenze, obergrenze);
                obergrenze--;

                if (a[untergrenze] < lowPivot)
                {
                    swap(a, untergrenze, i);
                    i++;
                }
            }
            untergrenze++;
        }
        i--;
        obergrenze++;

        // Bring pivots to their appropriate positions.
        swap(a, left, i);
        swap(a, right, obergrenze);

        // Returning the indices of the pivots
        // because we cannot return two elements
        // from a function, we do that using an array.
        pivots[0] = i;
        pivots[1] = obergrenze;
        return pivots;
    }


    private static void swap (int[] array, int indexA, int indexB) {
        int tmp = array[indexA];
        array[indexA] = array[indexB];
        array[indexB] = tmp;
    }

    public static void main(String[] args) {

        int n = 10;
        int[] a = new int[n];

        for (int i = 0; i < n; i++) {
            a[i] = (int) (Math.random() * 100);
        }

        System.out.println(Arrays.toString(a));

        //quickSort(a);
        dualPivotQuicksort(a);

        System.out.println(Arrays.toString(a));
    }
}

