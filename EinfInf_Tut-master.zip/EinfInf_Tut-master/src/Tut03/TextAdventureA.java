package Tut03;
import java.util.Scanner;

public class TextAdventureA {

    //Die Variablen sollen für alle Methoden gelten, deshalb müssen sie für die gesamte Klasse deklariert werden:
    static boolean hatSchluessel = false;
    static boolean hatMesser = false;
    static boolean erstesMalKueche = true;
    static boolean erstesMalWohnzimmer = true;
    static boolean gameOver = false;
    static int eintrittFlur = 0;

    public static String auswahlAB(){
        //Diese Methode gibt eine Auswahl des Spielers zurück. Die Auswahl erfolgt durch eine Eingabe über den Scanner
        //Dabei wird nur "a" oder "b" als gültige Eingabe erkannt.
        //Solang weder a noch b eingegeben wurde, wird der Spieler erneut um eine Eingabe gebeten.

        Scanner scanAB = new Scanner(System.in);
        String auswahlAB;
        while (true) {
            auswahlAB = scanAB.next();
            //Die Abbruchbedingung ist die Eingabe "a" oder "b":
            if (auswahlAB.equals("a") || auswahlAB.equals("b")) {
                break;
            }
            System.out.println("Auswahl erneut eingeben (a oder b): ");
        }
        return auswahlAB;
    }

    public static void kueche(){
        //kuecheEntscheidung erhält seinen Wert in der auswahlAB() Methode.
        String kuecheEntscheidung;

        //Hat der Spieler den Schlüssel noch nicht gefunden ist hatSchluessel 'false', er kann nicht in die
        //Küche eintreten und folgende Meldung erscheint:
        if (hatSchluessel == false) {
            System.out.println("\nDu versuchst die Tür zur Küche zu öffnen, aber sie ist " +
                    "verschlossen. Seltsam. Und jetzt? Der Schlüssel muss irgendwo sein!\n" +
                    "So kommst du jedenfalls nicht rein.");
        }
        //Wenn hatSchluessel 'true':
        else {
            //Dieser Text soll nur beim ersten Betreten der Küche erscheinen. Deshalb wird erstelMalKueche danach auf
            // 'false' gesetzt.
            if (erstesMalKueche) {
                System.out.println("Du schließt die Tür auf und trittst ein. ");
                erstesMalKueche = false;
            }

            //Für jedes weitere Betreten der Küche:
            else {
                System.out.println("Du bist in der Küche.");
            }
            //Auswahl erscheint bei jedem erfolgreichen Betreten der Küche:
            System.out.println("Was willst du tun?\na)Die Küche durchsuchen\nb)Zurück in den Flur");

            //kuecheEntscheidung erhält seinen Wert durch Nutzereingabe in der auswahlAB() Methode:
            kuecheEntscheidung = auswahlAB();

            //Wenn der Spieler zurück in den Flur will:
            if (kuecheEntscheidung.equals("b"))  {
                System.out.println("Zurück in den Flur...\n");}

            //Wenn der Spieler die Küche durchsucht und er das Messer noch nicht hat, also hatMesser = 'false':
            else if (kuecheEntscheidung.equals("a") && !hatMesser) {

                //Option, das gefundene Messer aufzunehmen oder nicht:
                System.out.println("Du findest nichts besonderes. Aber da ist ein Messer. Vielleicht könnte das " +
                        "nützlich sein. Willst du es nehmen?\na)Ja\nb)Nein");
                //Erneut wird kuecheEntscheidung durch Nutzereingabe in auswahlAB() geändert:
                kuecheEntscheidung = auswahlAB();

                //Wenn er das Messer nicht haben will:
                if (kuecheEntscheidung.equals("b")){
                    System.out.println("Na gut. Dann halt nicht.");
                    //Erneute Rückkehr zu kueche() und somit zum Anfang der Methode.
                    kueche();
                }

                //Wenn er das Messer mitnehmen will:
                else {
                    System.out.println("Besser ist es...\n");
                    //hatMesser wird 'true' und die Methode kueche() erneut aufgerufen:
                    hatMesser = true;
                    kueche();
                }
            }

            //Wenn er die Küche bereits durchsucht und das Messer gefunden hat gibt es nichts mehr zu finden:
            else {
                System.out.println("Du findest nichts hilfreiches...\n");
                //Rückkehr zum Anfang der Methode:
                kueche();
            }
        }
    }

    public static void badezimmer() {

        //badEntscheidung erhält später seinen Wert durch Nutzereingabe in auswahlAB().
        String badEntscheidung;

        //Anzeige der Optionen im Bad:
        System.out.println("\nDu bist im Bad. Sieht aus wie immer. Was willst du tun?\n");
        System.out.println("a) Das Bad unter die Lupe nehmen\nb) Zurück in den Flur");

        //badEntscheidung wird zu "a" oder "b":
        badEntscheidung = auswahlAB();

        //Wenn der Spieler zurück in den Flur will:
        if (badEntscheidung.equals("b"))  {
            System.out.println("Na gut, zurück in den Flur...");
        }

        //Wenn er das Bad durchsuchen will und den Schlüssel noch nicht gefunden hat (also hatSchluessel == 'false'):
        else if (badEntscheidung.equals("a") && !hatSchluessel) {
            //Der Spieler erhält den Schlüssel, der Wert wird auf 'true' geändert.
            hatSchluessel = true;
            System.out.println("Du findest den Schlüssel für die Küche. Seltsam, was macht der hier?\n" +
                    "Du steckst ihn lieber mal ein...");
            //Zurück zum Anfang der Methode:
            badezimmer();
        }
        //Wenn er das Bad durchsuchen will, aber den Schlüssel schon gefunden hat:
        else {
            System.out.println("Viel zu tun ist hier nicht mehr, außer natürlich du musst mal.");
            //Zurück zum Anfang der Methode:
            badezimmer();
        }
    }

    public static void wohnzimmer() {
        //Im Wohnzimmer kann der Spieler auf einen Zombie treffen. Je nachdem ob er das Messer gefunden hat kann er
        //ihn besiegen oder stirbt selber.

        //wohnzimmerEntscheidung erhält später seinen Wert durch Nutzereingabe in  der auswahlAB() Methode.
        String wohnzimmerEntscheidung;

        //Wenn der Spieler das Wohnzimmer nicht zum ersten Mal betritt soll folgender Text erscheinen:
        if (erstesMalWohnzimmer == false){
            System.out.println("Du betrittst den Raum. Der Zombie ist immer noch da. Wieder kommt er auf dich zu!" +
                    "\nWas tust du?\na)Kämpfen!\nb)Flüchten!");
        }
        //Beim ersten Versuch das Zimmer zu betreten soll der Spieler gewarnt und nochmals gefragt werden,
        //ob er wirklich eintreten will:
        if (erstesMalWohnzimmer == true) {
            System.out.println("Du öffnest die Tür einen Spalt weit und schaust ins Wohnzimmer...\n" +
                    "Da ist irgendwas oder irgendwer!\nEtwas steht im Zimmer und macht Geräusche.\n" +
                    "Was wirst du tun?\na)Schnell in den Flur zurück!\nb)Ich trete ein.");

            //wohnzimmerEntscheidung erhält einen Wert in auswahlAB() Methode:
            wohnzimmerEntscheidung = auswahlAB();

            //Wenn der Spieler doch nicht eintreten will:
            if (wohnzimmerEntscheidung.equals("a")){
                System.out.println("\nLeise schließt du die Tür wieder...");
                //erstesMalWohnzimmer wird 'false' und es wird in die main Methode zurückgekehrt:
                erstesMalWohnzimmer = false;
                return;
            }
            //Wenn er eintreten will erscheint eine Auswahl zu kämpfen oder zu flüchten und erstesMalWohnzimmer wird
            //auf 'false' gesetzt:
            else if (wohnzimmerEntscheidung.equals("b")){
                System.out.println("Du tritts ein und siehst dir die Gestalt etwas genauer an.\n" +
                        "Es ist ein Zombie!\nEr hat dich bemerkt und kommt auf dich zu!" +
                        "\nWas tust du?\na)Kämpfen!\nb)Flüchten!");
                erstesMalWohnzimmer = false;

            }
        }
        //Diese Auswahl kommt entweder nach der Auswahl in Zeile 143 oder Zeile 167:
        wohnzimmerEntscheidung = auswahlAB();

        //Will er kämpfen und hat das Messer, erscheint folgender Text. Der Spieler gewinnt das Spiel.
        //Dann wird gameOver auf 'true' gesetzt, wodurch die while Schleife in der main Methode und somit das Spiel
        //beendet wird.
        if (wohnzimmerEntscheidung.equals("a") && hatMesser){
            System.out.println("Der Zombie kommt immer näher, aber du ziehst das Messer, das du aus der" +
                    " Küche mitgenommen hast.\nEr versucht dich zu beißen, aber du rammst ihm die Klinge in" +
                    " den Schädel. Röchelnd bricht er zusammen und bleibt regungslos liegen. Geschafft!");
            gameOver = true;

        }
        //Will er kämpfen und hat das Messer nicht, erscheint folgender Text. Der Spieler verliert das Spiel.
        //Dann wird gameOver auf 'true' gesetzt, wodurch die while Schleife in der main Methode und somit das Spiel
        //beendet wird.
        else if (wohnzimmerEntscheidung.equals("a") && !hatMesser){
            System.out.println("Der Zombie stürzt sich mit ausgebreiteten Armen auf dich.\nDu versuchst dich" +
                    " zu wehren, aber ohne Waffe bist du ihm schutzlos ausgeliefert.\nWährend er seine Zähne in" +
                    " deinem Hals versenkt, denkst du daran, dass du dein Dasein ab sofort\nwohl auch als" +
                    " Zombie fristen wirst. Dann wirst du ohnmächtig und sackst zu Boden.\nDas wars.\n\nSchade!");
            gameOver = true;
        }
        //Wenn er flüchten will erscheint folgender Text und das Programm der Spieler kehrt zur Auswahl im Flur zurück:
        else {
            System.out.println("Du stürzt durch die Tür und machst sie zu.\n" +
                    "Der Zombie bleibt zum Glück im Wohnzimmer.");
        }

    }

    public static String imFlur() {
        //Zentraler Bereich, von dem die Zimmer abgehen. Jedes mal, wenn der Spieler hier landet, wird er gefragt,
        //welchen Raum er betreten will.

        //Der Zähler eintrittFLur ist nur dafür da, dem Spieler beim ersten "Eintreten" (also Aufrufen der Methode)
        // einen anderen Text anzuzeigen als im folgenden Verlauf des Spiels.
        eintrittFlur++;

        //beim ersten Betreten:
        if (eintrittFlur == 1){
            System.out.println("Du betrittst den Flur.\nAus der Richtung deines Wohnzimmers kommen seltsame" +
                    " Geräusche.\nEs klingt wie ein röcheln.\nDu überlegst was du tust.\nDu könntest in die" +
                    " Küche gehen, das Bad inspizieren oder den Geräuschen im Wohnzimmer auf den Grund gehen...\n");
        }

        //beim Zurückkehren in den Flur:
        else {System.out.println("\nDu stehst wieder im Flur. Was willst du tun?");}
        System.out.println("a) In die Küche gehen\nb) Ins Bad gehen\nc) Ins Wohnzimmer gehen");

        //Scanner als Methode zur Nutzereingabe.
        Scanner flur = new Scanner(System.in);
        //entscheidungFlur nimmt Eingabewert als String an.
        String entscheidungFlur;

        //Ähnlich zu auswahlAB() eine while Schleife, die erst beendet wird, wenn der User "a","b" oder "c" eingibt.
        //Ansonsten wird er zu erneuter Eingabe aufgefordert.
        //entscheidungFlur wird dann zurückgegeben.
        while (true) {
            entscheidungFlur = flur.next();
            if (entscheidungFlur.equals("a") || entscheidungFlur.equals("b") || entscheidungFlur.equals("c")) {
                break;
            }
            System.out.println("Auswahl erneut eingeben (a, b oder c): ");
        }
        return entscheidungFlur;
    }

    public static void main (String[] args){

        //Speichert die Entscheidung des Spielers (a oder b)
        String entscheidung;

        //Spieler wird gefragt ob er eintreten will oder nicht.
        System.out.println("Du kommst abends aus der Uni nach Hause.\nSchon im Hausflur, vor deiner Wohnung fällt" +
                " dir auf, dass etwas nicht stimmt.\nDie Tür ist nicht geschlossen, sondern steht einen Spalt" +
                " breit auf.\nWas wirst du tun?");
        System.out.println("a) Ich trete ein\nb) Ich hau lieber ab!");

        //entscheidung erhält einen Wert.
        entscheidung = auswahlAB();

        //Programm bricht ab, wenn Spieler nicht eintreten will.
        if (entscheidung.equals("b")) {
            System.out.println("Alles klar. Ist auch besser so.");
            System.exit(0);
        }

        //Wenn er eintritt, kommt hier eine while Schleife, die erst verlassen wird, wenn gameOver 'true' ist.
        while (true){

            //entscheidung erhält bei jedem Durchlauf in der imFlur() Methode einen neuen Wert vom Spieler.
            //Je nach Entscheidung wird eine andere Methode aufgerufen.
            entscheidung = imFlur();
            if (entscheidung.equals("a")) {
                kueche();
            }
            else if (entscheidung.equals("b")) {
                badezimmer();
            }
            else if (entscheidung.equals("c")) {
                wohnzimmer();
            }
            if (gameOver) break;

        }
        System.out.println("\nVielen Dank fürs spielen. Hoffentlich hat es Spaß gemacht.");
    }

}