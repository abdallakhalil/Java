package Tut03;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.Color;
import java.io.File;

public class Dithering {
    public static  void main(String[] args){
        String filePath = "";

        //Abfangen bei fehlenden Eingaben
        try{
            filePath = args[0];          //speichert den Dateipfad mit Namen des Bildes
        } catch (Exception e){
            System.out.println(("Bitte geben sie einen gueltigen Dateipfad ein."));
        }
        BufferedImage image = null;

        // Abfangen ungültiger Eingaben
        try {
            image = ImageIO.read(new File(filePath));
        } catch (Exception e) {
            System.err.println("Das Bild konnte nicht gefunden werden.");
            System.exit(1);
        }

        // Bestimmung der Bildmaßen
        int imgHeight = image.getHeight();
        int imgWidth = image.getWidth();
        int compresFactor = 0;

        // Bestimmung des Kompressionsfaktors abhängig von der Bildgröße
        // (eigentlich nur aus Bildhöhe, da pacman.png quadratatisch ist)
        if (imgHeight <= 500) {
            compresFactor = 10;
        } else if (imgHeight <= 1000) {
            compresFactor = 40;
        } else if (imgHeight <= 2000)  {
            compresFactor = 50;
        } else {
            compresFactor = 100;
        }

        // Bestimmung der Bildmaßen des komprimierten Bildes
        int compresImgHeight = (imgHeight / compresFactor);
        int compresImgWidth = (imgWidth / compresFactor);

        //speichert Werte von 0.0 bis 255.0 des Originalbildes
        double[][] greyscales = new double[imgHeight][imgWidth];
        //speichert Werte von 0.0 bis 255.0 des komprimiertem Bildes
        double[][] compGreyscale = new double[compresImgHeight][compresImgWidth];
        // speichert die Chars, die entsprechend der Grauwertetabelle eingesetzt wurden
        char[][] charReplacement = new char[compresImgHeight][compresImgWidth];

        int red,green,blue; // speichert Wert zwsichen 0.0 und 255.0 als Anteil der Farbe
        int value = 0;      // speichert temporär den Rot-, Grün- und Blauwert pro Pixel
        double r_greyscale = 0.0;   // speichert Wert zwsichen 0.0 und 255.0 als Rotwert ab
        double g_greyscale = 0.0;   // speichert Wert zwsichen 0.0 und 255.0 als Blauwert ab
        double b_greyscale = 0.0;   // speichert Wert zwsichen 0.0 und 255.0 als Blauwert ab
        double greyscale = 0.0;     // speichert Wert zwsichen 0.0 und 1.0 als Grauwert ab
        double summeGreyscale = 0.0;    //speichert die Summe bestimmter Grauwerte (wird zum Komprimieren gebraucht)
        int chargreyscale = 0;      //speichert den Grauwert, der später (pro Pixel) in der Wertetabelle verglichen wird.


        // Das Array greyscales wird mit Werten zwischen 0.0 und 255.0 für jeden Pixel befüllt
        for (int i=0; i < imgHeight; i++) {
            for (int j=0; j < imgWidth; j++) {

                value = image.getRGB(j, i);   // RGB Wert für jeden Pixel

                Color c = new Color(value);
                red = c.getRed();           //Bestimmung des Rotwertes
                green = c.getGreen();       //Bestimmung des Grünwertes
                blue = c.getBlue();         //Bestimmung des Blauwertes

                //Berechnung der Grauwerte der einzelnen Farbeanteile
                r_greyscale = red/255.0;
                g_greyscale = green/255.0;
                b_greyscale = blue/255.0;

                //Berechnung des Grauwertes [0,1] aus Grauwertanteile der Farben
                greyscale = 0.30 * r_greyscale + 0.59 * g_greyscale + 0.11 * b_greyscale;

                //Grauwert wird mit 255.0 multipliziert um Werte von  0.0 bis 255.0 zu erhalten
                greyscales[j][i] = 255.0 * greyscale;
            }
        }

        //Das Bild wird komprimiert. Dazu werden, abhängig vom Kompressionsfaktor (compresFactor),
        //z.B. immer 10 aufeinanderfolgende Pixel zusammengefasst. Dazu wird aus den einzelnen Grauwerten
        // eine Summe gebildet und durch die Anzahl der einzelnen Werte dividiert.
        for (int i=0; i < imgHeight; i++) {
            for (int j = 0; j < imgWidth; j++) {

                //wenn j+1 restlos durch compresFactor geteilt werden kann, wurden z.B 10 Pixelwerte addiert
                if ( ((j+1) % compresFactor) == 0 ){
                    // da i und j noch im Bereich des Originalbildes ablaufen, müssen diese durch den
                    // Kompressionsfaktor geteilt werden.
                    compGreyscale[j/compresFactor][i/compresFactor] = (summeGreyscale / compresFactor);
                    summeGreyscale = 0;
                }
                summeGreyscale += greyscales[j][i];
            }
        }

        //Bestimmung der Char mit Hilfe der Grauwerte des komprimiertem Bildes
        for (int i=0; i < compresImgHeight; i++) {
            for (int j=0; j < compresImgWidth; j++) {

                chargreyscale = (int) compGreyscale[j][i];

                //Grauwerttabelle
                if (chargreyscale <= 50) {
                    charReplacement[j][i] = ' ';
                } else if (chargreyscale <= 101) {
                    charReplacement[j][i] = '\u2591';
                } else if (chargreyscale <= 152) {
                    charReplacement[j][i] = '\u2592';
                } else if (chargreyscale <= 203) {
                    charReplacement[j][i] = '\u2593';
                } else if (chargreyscale <= 255) {
                    charReplacement[j][i] = '\u2588';
                } else {
                    charReplacement[j][i] = '#';        //Bei fehlerhafter Bestimmung wird # verwendet
                }
            }
        }

        // Ausgabe
        for (int i=0; i < compresImgHeight; i++) {
            System.out.println(" ");
            for (int j=0; j < compresImgWidth; j++) {
                // Die entsprechenden Char pro Pixel werden doppelt ausgegeben, da die Char deutlich höher als breiter
                //sind. Daraus folgt, dass die Ausgabe  deutlich näher an einem quadratischem Bild ist.
                System.out.print(charReplacement[j][i]);
                System.out.print(charReplacement[j][i]);
            }
        }
    }
}
